﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Xml;
using Microsoft.Win32;

namespace Maa
{
    public partial class Form1 : Form
    {
       

        bool isPanelClosed;
        public Form1()
        {
            InitializeComponent();
        }
        
  
        private void pictureBox2_Click(object sender, EventArgs e)
        {
           
            this.Close();
        }

        private void SidePanel_MouseHover(object sender, EventArgs e)
        {
            timer1.Start();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            switch (isPanelClosed)
            {
                case true:
                    if (SidePanel.Width <= button1.Width)
                    {
                        SidePanel.Size = new Size(SidePanel.Width + 5, SidePanel.Height);
                      //  pictureBox1.Left += 4;

                    }
                    else
                    {
                        isPanelClosed = false;
                        timer1.Stop();
                    }
                    break;
                default:
                    if (SidePanel.Width > 67)
                    {
                        SidePanel.Size = new Size(SidePanel.Width - 5, SidePanel.Height);
                      //  pictureBox1.Left -= 4;
                    }
                    else
                    {
                        timer1.Stop();
                        isPanelClosed = true;
                    }
                    break;
            }
        }

        private void panel2_MouseHover(object sender, EventArgs e)
        {
            if (SidePanel.Width >= button1.Width)
            {
                isPanelClosed = false;
                timer1.Start();
            }

        }


        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if(this.WindowState != FormWindowState.Minimized)
            {
                this.WindowState = FormWindowState.Minimized;
            }
        }

     
        private void Form1_Load(object sender, EventArgs e)
        {
            SetAssociation(".Math", "Custom", @"‪C:\Users\Sajjad\source\repos\M\M\bin\Debug\M.exe", "Math");

        }
        public static void SetAssociation(string Extension, string KeyName, string OpenWith, string FileDescription)
        {
            RegistryKey BaseKey;
            RegistryKey OpenMethod;
            RegistryKey Shell;

            BaseKey = Registry.ClassesRoot.CreateSubKey(Extension);
            BaseKey.SetValue("", KeyName);

            OpenMethod = Registry.ClassesRoot.CreateSubKey(KeyName);
            OpenMethod.SetValue("", FileDescription);
            OpenMethod.CreateSubKey("DefaultIcon").SetValue("", @"C:\Users\Sajjad\Dropbox\C#\matlab\ico.ico");
            Shell = OpenMethod.CreateSubKey("Shell");
            Shell.CreateSubKey("edit").CreateSubKey("command").SetValue("", "\"" + OpenWith + "\"" + " \"%1\"");
            Shell.CreateSubKey("open").CreateSubKey("command").SetValue("", "\"" + OpenWith + "\"" + " \"%1\"");
            BaseKey.Close();
            OpenMethod.Close();
            Shell.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            matricess1.BringToFront();
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            expp1.BringToFront();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            bio1.BringToFront();
        }

        private void bio1_Load(object sender, EventArgs e)
        {

        }

     
        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            timer1.Start();
            if (SidePanel.Width >= button1.Width)
            {
                isPanelClosed = false;
                timer1.Start();
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            workBook1.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            console1.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            shapes1.BringToFront();
        }

        private void console1_Load(object sender, EventArgs e)
        {

        }
    }
}
