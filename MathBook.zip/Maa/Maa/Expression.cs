﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Maa
{
    class Expression
    {
        List<Term> terms = new List<Term>();
        public List<Term> Terms { get { return terms; } set { terms = value; } }
        public Expression()
        {

            Term t = new Term(1, 0);
            terms.Add(t);

        }
        public Expression(List<Term> terms)
        {
            for (int i = 0; i < terms.Count; i++)
            {
                this.terms.Add(terms[i]);
            }
        }
        public Expression(string expression)
        {
          
            this.ReadPolyExpression(expression);
        }
        public static Expression operator +(Expression e,Expression e1)
        {
            AddTermsOfSamePowers(ref e);
            AddTermsOfSamePowers(ref e1);
            List<Term> terms1 = new List<Term>();
            Expression expression = new Expression();
          
             for (int i = 0; i < e.terms.Count; i++)
                {
                
                    for (int j = 0; j < e1.terms.Count; j++)

                    {
                        if (e.terms[i].power == e1.terms[j].power)
                        {
                            terms1.Add(e.terms[i] + e1.terms[j]);
                            e.terms.Remove(e.terms[i]);
                            e1.terms.Remove(e1.terms[j]);
                            j=10000;i--;

                        }
                    

                    }
                
                }
          
            for (int i = 0; i < e.terms.Count; i++)
            {
                terms1.Add(e.terms[i]);

            }
            for (int i = 0; i < e1.terms.Count; i++)
            {
                terms1.Add(e1.terms[i]);
            }
                expression = new Expression(terms1);

                return expression;
            }
        public static Expression operator+(Expression e,double e1)
        {
            double a;
            AddTermsOfSamePowers(ref e);
            Term t = new Term();
            List<Term> terms1 = new List<Term>();
            Expression expression = new Expression();

            for (int i = 0; i < e.terms.Count; i++)
            {

              
                    if (e.terms[i].power ==0)
                    {
                    a = terms1[i].coefficient + e1;
                    t = new Term(a, 0);
                    terms1.Add(t);

                    }
                    else
                {
                    terms1.Add(e.terms[i]);
                }
               
            }
            return expression = new Expression(terms1);
        }
        public static Expression operator-(Expression e,Expression e1)
        {
            AddTermsOfSamePowers(ref e);
            AddTermsOfSamePowers(ref e1);
            List<Term> terms1 = new List<Term>();
            Expression expression = new Expression();
            for (int i = 0; i < e1.terms.Count; i++)
            {
                e1.terms[i]=(e1.terms[i] * -1);
            }
            for (int i = 0; i < e.terms.Count; i++)
            {
                for (int j = 0; j < e1.terms.Count; j++)
                {
                    if (e.terms[i].power == e1.terms[j].power)
                    {
                        terms1.Add(e.terms[i] + e1.terms[j]);
                        e.terms.Remove(e.terms[i]);
                        e1.terms.Remove(e1.terms[j]);
                        j = 10000; i--;

                    }
                }
            }
            for (int i = 0; i < e.terms.Count; i++)
            {
                terms1.Add(e.terms[i]);
            }
            for (int i = 0; i < e1.terms.Count; i++)
            {
                terms1.Add(e1.terms[i]);
            }
            expression = new Expression(terms1);
            return expression;
        }
        public static Expression operator*(Expression e,Expression e1)
        {
            AddTermsOfSamePowers(ref e);
            AddTermsOfSamePowers(ref e1);
            List<Term> terms1 = new List<Term>();
            for (int i = 0; i < e.terms.Count; i++)
            {
                for (int j = 0; j < e1.terms.Count; j++)
                {
                    terms1.Add(e.terms[i] * e1.terms[j]);
                }
            }
            Expression expression = new Expression(terms1);
            return expression;
        }
        /// <summary>
        /// Expression exponent of positive integer
        /// </summary>
        /// <param name="e"></param>
        /// <param name="n"></param>
        /// <returns></returns>
        public static Expression operator^(Expression e,int n)
        {
            AddTermsOfSamePowers(ref e);
            
            Term term = new Term();
            List<Term> t = new List<Term>();
            if (n>0)
            {
                if (e.terms.Count == 2)
                {
                    // calculating the value of n!

                    int nFact = factorial(n);

                    // loop to display the series    

                    for (int i = 0; i < n + 1; i++)
                    {
                        // For calculating the 

                        // value of nCr 

                        int niFact = factorial(n - i);

                        int iFact = factorial(i);

                        // calculating the value of A to the power k and X to  the power k 

                        Term aPow = e.terms[0] ^ (n - i);
                        Term xPow = e.terms[1] ^ i;
                        t.Add((nFact * aPow * xPow) / (niFact * iFact));

                    }

                }
                else { throw new Exception("Not more than two terms"); }


            }
            else
            { throw new Exception("Input positive integer"); }

            Expression e2 = new Expression(t);
           AddTermsOfSamePowers(ref e2);
            return e2;
        }
        /// <summary>
        /// Read expression in string
        /// </summary>
        /// <param name="PolyExpression"></param>
        private void ReadPolyExpression(string PolyExpression)
        {
            if (ValidateExpression(PolyExpression))
            {
                string NextChar = string.Empty;
                string NextTerm = string.Empty;
                for (int i = 0; i < PolyExpression.Length; i++)
                {
                    NextChar = PolyExpression.Substring(i, 1);
                    if ((NextChar == "-" | NextChar == "+") & i > 0)
                    {
                        Term TermItem = new Term(NextTerm);
                        this.terms.Add(TermItem);
                        NextTerm = string.Empty;
                    }
                    NextTerm += NextChar;
                }
                Term Item = new Term(NextTerm);
                this.terms.Add(Item);


            }
            else
            {
                throw new Exception("Invalid Polynomial Expression");
            }
        }
        /// <summary>
        ///  Is Valid Expression 
        /// </summary>
        /// <param name="Expression"></param>
        /// <returns></returns>
        public static bool ValidateExpression(string Expression)
        {
            if (Expression.Length == 0)
                return false;

            Expression = Expression.Trim();
            Expression = Expression.Replace(" ", "");
            while (Expression.IndexOf("--") > -1 | Expression.IndexOf("++") > -1 | Expression.IndexOf("^^") > -1 | Expression.IndexOf("xx") > -1 )
            {
                Expression = Expression.Replace("--", "-");
                Expression = Expression.Replace("++", "+");
                Expression = Expression.Replace("^^", "^");
                Expression = Expression.Replace("xx", "x");
              
            }
            string ValidChars = "+-x1234567890^";
            bool result = true;
            foreach (char c in Expression)
            {
                if (ValidChars.IndexOf(c) == -1)
                    result = false;
            }
            return result;
        }
        /// <summary>
        /// Factorial
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        static int factorial(int n)

        {

            int f = 1;

            for (int i = 2; i <= n; i++)

                f *= i;



            return f;

        }
        private bool CheckForTermsAvailability(Term t)
        {

            for (int i = 0; i < terms.Count; i++)
            {
                Term temp = terms[i];
                if (t.power == temp.power)
                {
                    temp.power += t.power;
                    temp.coefficient += t.coefficient;
                    return true;
                }
            }
            return false;
        }
        public Term GetTermAtIndex(int i)
        {
            if (i < terms.Count)
            {
                Term t = (Term)terms[i];
                return t;
            }
            else
                throw new Exception("The limit of collection is exceeded.");
        }
        public void RemoveTermAtIndex(int i)
        {
            if (i < terms.Count)
            {
                terms.RemoveAt(i);
            }
            else
                throw new Exception("The limit of collection is exceeded.");
        }
        public double Evaluate(double point)
        {
            double sum = 0;
            for (int i = 0; i < terms.Count; i++)
            {
                Term t = terms[i];
                sum += t.Evaluate(point);
            }
            return sum;
        }
        public static KeyValuePair<double,double> SolveforX(Expression e)
        {
            double x, x1;
            double a = 0, b = 0, c = 0;
          
            for (int i = 0; i < e.terms.Count; i++)
            {
                if (e.terms[i].power==2)
                {
                    a = e.terms[i].coefficient;
                }
                else if(e.terms[i].power==1)
                {
                    b = e.terms[i].coefficient;
                }
                else if(e.terms[i].power==0)
                {
                    c = e.terms[i].coefficient;
                }
             
            }
            if (a!=0 && b!=0 && c!=0)
            {
                x = ((-b + (Math.Sqrt((b * b) - (4 * a * c)))) / (2 * a));
                x1 = ((-b -(Math.Sqrt((b * b) - (4 * a * c)))) / (2 * a));
            }
            else
            {
                throw new Exception("Cannot determine");
            }
            return new KeyValuePair<double, double>(x,x1);
          
        }
        private int GetMaximumPower()
        {
            int max = 0;
            for (int i = 0; i < terms.Count; i++)
            {
                Term t = terms[i];
                if (t.power > max)
                    max = t.power;
            }
            return max;
        }
        public Expression Getdegree(ref Expression terms)
        {
            int temp = 0;
     
            for (int write = 0; write < terms.terms.Count; write++)
            {
                for (int sort = 0; sort < terms.terms.Count - 1; sort++)
                {
                    if (terms.terms[sort].power < terms.terms[sort + 1].power)
                    {
                        temp = terms.terms[sort + 1].power;
                        terms.terms[sort + 1] = terms.terms[sort];
                        terms.terms[sort].power = temp;
                    }
                }
               
            }
            return terms;
            
        }
        
        private static void AddTermsOfSamePowers(ref Expression list)
        {
            for (int i = 1; i < list.terms.Count; i++)
            {
                Term t1 = list.terms[i];
                for (int j = 0; j < i; j++)
                {
                    Term t2 = list.terms[j];
                    if (t1.power == t2.power)
                    {
                        t2.coefficient += t1.coefficient;
                        list.terms.RemoveAt(i);
                        i--;
                    }
                }
            }
        }
        public static Expression Differentiate(Expression expression)
        {
        
            List<Term> t = new List<Term>();
            for (int i = 0; i < expression.terms.Count ; i++)
            {
               
                t.Add( Term.Differentiate(expression.terms[i]));
                
            }
            Expression expression1 = new Expression(t);
            AddTermsOfSamePowers( ref expression1);
            return expression1;
        }
        public static Expression Integrate(Expression expression)
        {
            List<Term> t = new List<Term>();
            for (int i = 0; i < expression.terms.Count; i++)
            {

                t.Add(Term.Intergrate(expression.terms[i]));

            }
            Expression expression1 = new Expression(t);
            AddTermsOfSamePowers(ref expression1);
            return expression1;
        }
        /// <summary>
        /// Long division
        /// </summary>
        /// <param name="divisor"></param>
        /// <param name="divident"></param>
        /// <returns></returns>
        public static Tuple<Expression,string> operator/(Expression divisor,Expression divident)
        {
            int r = 0;
            string ss = "";
            List<Term> t = new List<Term>();
            Expression d = new Expression(divident.terms);
            for (int i = 0; i < divident.terms.Count; i++)
            {
                Term value = d.Getdegree(ref d).terms[0] / divisor.Getdegree(ref divisor).terms[0];
                if(value.power<0  )
                {

                    for (int ii = 0; ii < d.terms.Count; ii++)
                    {
                        if (d.terms[ii].coefficient != 0)
                        {
                            if (d.terms[ii].coefficient != 0 && r==0)
                                ss +="+" + d + "/" + divisor; r++;d.terms.RemoveAt(ii);
                            
                        }
                    }
                    continue;

                }
                t.Add(value);
                
                Expression s = value * divisor;
                d = d - s;
                d.terms.RemoveAt(0);  
            }
            return Tuple.Create(new Expression(t), ss);
           

        }
        public static Expression operator *(Term t,Expression e)
        {
            List<Term> terms = new List<Term>();
          
            for (int i = 0; i < e.terms.Count; i++)
            {
                terms.Add( e.terms[i] * t);
            }
            Expression e1 = new Expression(terms);
            return e1;
        }
        public override string ToString()
        {
            string s = "";
            for (int i = 0; i < terms.Count; i++)
            {
                if (Math.Sign(terms[i].coefficient)==1 && i==0)
                {
                    s += ""+terms[i];
                }
                else if(Math.Sign(terms[i].coefficient) == 1)
                {
                    s += "+" + terms[i];

                }
                else if (Math.Sign(terms[i].coefficient) == -1)
                {
                    s +=  terms[i]+"";
                }
             
                else
                {
                    s += "";
                }
                
            }
            return s;
        }
    }
}
