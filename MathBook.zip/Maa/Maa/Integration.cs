﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maa
{
    class Integration
    {
        Expression Expression;
        public Integration()
        {
            Expression = new Expression();
        }
        public Integration(Expression Expression)
        {
            this.Expression = Expression;
        }
        private double SimpsonIntegration(double low, double high, double noPartition)
        {
            double x, h, sum1 = 0.0, sum2 = 0.0, area;
            h = (high - low) / noPartition;

            x = low + (2 * h);
            for (int i = 2; i <= noPartition - 2; i += 2)
            {
                sum1 += Fun(x);
                x += 2.0 * h;
            }

            x = low + h;
            for (int i = 1; i <= noPartition - 1; i += 2)
            {
                sum2 += Fun(x);
                x += 2.0 * h;
            }
            area = (h / 3) * (Fun(low) + Fun(high) + (2.0 * sum1) + (4.0 * sum2));

            return area;
        }
        private double TrapezoidalIntegration(double low, double high, double noPartition)
        {
            double x, h, sum = 0.0, area;
            h = (high - low) / noPartition;
            x = low + h;
            for (int i = 0; i < noPartition - 1; i++)
            {
                sum += Fun(x);
                x += h;
            }

            area = 0.5 * h * ((Fun(low) + Fun(high) + (2 * sum)));

            return area;
        }
        private double RectIntegration(double low, double high, double noPartition)
        {
            double x, h, sum = 0.0, area;
            h = (high - low) / noPartition;
            x = low;
            for (int i = 1; i < noPartition + 1; i++)
            {
                sum += Fun(x);
                x += h;
            }

            area = sum * h;

            return area;
        }

        private double Fun(double x)
        {
            return Expression.Evaluate(x);
        }
    }
}
