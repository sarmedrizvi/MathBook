﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maa
{
    class Binomial
    {

       public static int factorial(int n)

        {
            int f = 1;
            for (int i = 2; i <= n; i++)

                f *= i;

            return f;

        }
        public static int nCr(int numberOfTerms, int requiredTerm)
        {
            if (numberOfTerms < 0 && requiredTerm < 0)
            {
                throw new Exception("Input positive integer");
            }
            else
            {
                int nrFact = 0;
                int rFact = 0;
                nrFact = factorial(numberOfTerms - requiredTerm);
                rFact = factorial(requiredTerm);
                int nfact = factorial(numberOfTerms);
                return nfact / (nrFact * rFact);
            }
        }
        public static int nPr(int numberOfTerms, int requiredTerm)
        {
            if (numberOfTerms < 0 && requiredTerm < 0)
            {
                throw new Exception("Input positive integer");
            }
            else
            {
                int nfact = 0, nrfact = 0;
                nfact = factorial(numberOfTerms);
                nrfact = factorial(numberOfTerms - requiredTerm);
                return nfact / nrfact;
            }
        }
        public static Term RequiredTerm(Expression term1,int noOfTerms,int requiredTerm)
        {
            if (term1.Terms.Count!=2)
            {
                throw new Exception("Enter correct terms");
            }
            if (noOfTerms < 0 && requiredTerm < 0)
            {
                throw new Exception("Input positive integer");
            }
            else
               
            return nCr(noOfTerms, requiredTerm) * (term1.Terms[0] ^ (noOfTerms - requiredTerm)) * (term1.Terms[1] ^ requiredTerm);

        }
        public static int NumberOfTerms(int powerOnBinomial)

        {
            return powerOnBinomial + 1;
        }
        public static Expression BinonialExpansion(Expression term1, double powerOnBinomial)
        {
            if (term1.Terms.Count != 2)
            {
                throw new Exception("Enter correct terms");
            }
            if (powerOnBinomial % 1 > 0 || powerOnBinomial<0)
            {
                throw new Exception("Number Should be Positive integer");

            }
            else
            {
                List<Term> terms = new List<Term>();
                terms.Add(term1.Terms[0]);
                terms.Add(term1.Terms[1]);
                Expression expression = new Expression(terms);
                Expression e = expression ^ (int)powerOnBinomial;
                return e;
            }
        }
     
        public static Tuple<int,Term,int, Term>  MiddleTerm(Expression expression, double powerOnBinomial)
        {
            if (expression.Terms.Count != 2)
            {
                throw new Exception("Enter correct terms");
            }
            int number1, number2, number;
            Term term, term11, t;
            if (powerOnBinomial % 1 > 0 || powerOnBinomial < 0)
            {
                throw new Exception("Number Should be Positive integer");
            }
            else
            {
                if (powerOnBinomial % 2 != 0)
                {
                    number1 = (int)(powerOnBinomial+1) / 2;
                    number2 = (int)(powerOnBinomial + 3 )/ 2;
                    term = RequiredTerm(expression, (int)powerOnBinomial, number1);
                    term11 = RequiredTerm(expression, (int)powerOnBinomial, number2);
                    return Tuple.Create(number1, term, number2, term11);
                  
                }
                else if(powerOnBinomial%2 ==0)
                {

                    number = (int)powerOnBinomial / 2;
                    t = RequiredTerm(expression, (int)powerOnBinomial, number);
                    return Tuple.Create(number, t,0,new Term());

                }
                else
                {
                    throw new Exception("Not a odd or even Number");
                }
            }
        }
        public static Term TermIndependedOfX(Expression expression,double powerOnBinomial)
        {
            if (expression.Terms.Count != 2)
            {
                throw new Exception("Enter correct terms");
            }
            if (powerOnBinomial % 1 > 0 || powerOnBinomial < 0)
            {
                throw new Exception("Number Should be Positive integer");
            }
            else
            {
                int a, b, number;
                a = expression.Terms[0].power < 0 ? -expression.Terms[0].power : expression.Terms[0].power;
                b = expression.Terms[1].power < 0 ? -expression.Terms[1].power : expression.Terms[1].power;
                number = ((int)powerOnBinomial * a) / (a + b);
                return RequiredTerm(expression, (int)powerOnBinomial, number);
            }
        }
        //public static double CoefficientOfRequiredPower(Term t,Term t1,double poweOnBinomial,int requiredPower)
        //{
        //    if (poweOnBinomial % 1 > 0)
        //    {
        //        throw new Exception("Number Should be Positive integer");
        //    }
        //    else
        //    {
        //        int r = (2 * (int)poweOnBinomial) - requiredPower;
        //      return  RequiredTerm(t, t1,(int) poweOnBinomial, r).coefficient;

        //    }
        //}
        public static double SumOfCoefficient(Expression expression,double powerOnBinomial)
        {
            if (expression.Terms.Count != 2)
            {
                throw new Exception("Enter correct terms");
            }
            if (powerOnBinomial % 1 > 0 || powerOnBinomial < 0)
            {
                throw new Exception("Number Should be Positive integer");
            }
            else
            {
                double number = 0;
                Expression e = BinonialExpansion(expression, powerOnBinomial);
                for (int i = 0; i < e.Terms.Count; i++)
                {
                    number += e.Terms[i].coefficient;
                }
                return number;
            }
        }
        public static double SumOfOddCoefficient(Expression expression, double powerOnBinomial)
        {
            if (expression.Terms.Count != 2)
            {
                throw new Exception("Enter correct terms");
            }
            if (powerOnBinomial % 1 > 0 || powerOnBinomial < 0)
            {
                throw new Exception("Number Should be Positive integer");
            }
            else
            {
                double number = 0;
                Expression e = BinonialExpansion(expression, powerOnBinomial);
                for (int i = 0; i < e.Terms.Count ;i++)
                {
                    if (i%2!=0)
                    {
                        number += e.Terms[i].coefficient;
                    }
                    
                }
                return number;
            }
        }
        public static double SumOfEvenCoefficient(Expression expression, double powerOnBinomial)
        {
            if (expression.Terms.Count != 2)
            {
                throw new Exception("Enter correct terms");
            }
            if (powerOnBinomial % 1 > 0 || powerOnBinomial < 0)
            {
                throw new Exception("Number Should be Positive integer");
            }
            else
            {
                double number = 0;
                Expression e = BinonialExpansion(expression, powerOnBinomial);
                for (int i = 0; i < e.Terms.Count; i++)
                {
                    if (i % 2 == 0)
                    {
                        number += e.Terms[i].coefficient;
                    }

                }
                return number;
            }
        }




    }
}
