﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Maa
{
    public partial class Expp : UserControl
    {
       
      

        public Expp()
        {
            InitializeComponent();
        }

        private void richTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
          
            if (e.KeyChar=='x' || e.KeyChar == '.' || e.KeyChar == '+' || e.KeyChar == '-' || e.KeyChar == '*' || e.KeyChar == '^')
            {

            }
            else
            {
                e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)  ; ;
            }
                
        }

        private void richTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }
        }

        private void Expp_Load(object sender, EventArgs e)
        {

            richTextBox2.Text = "";
            
        }

        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            try
            {
                Expression expression = new Expression(richTextBox1.Text);
                Expression ex = new Expression(textBox1.Text);
                Expression exx = expression + ex;
                richTextBox2.Text = exx.ToString();
                History.Items.Add("(" + richTextBox1.Text + ") + (" + textBox1.Text + ") = " + richTextBox2.Text);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar == 'x' || e.KeyChar == '.' || e.KeyChar == '+' || e.KeyChar == '-' || e.KeyChar == '*' || e.KeyChar == '^')
            {

            }
            else
            {
                e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar); ;
            }
        }

        private void richTextBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {

            try
            {
                Expression expression = new Expression(richTextBox1.Text);
                Expression ex = new Expression(textBox1.Text);
                Expression exx = expression - ex;
                richTextBox2.Text = exx.ToString();
                History.Items.Add("(" + richTextBox1.Text + ") - (" + textBox1.Text + ") = " + richTextBox2.Text);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void originalButtoncs3_ButtonClick(object sender, EventArgs e)
        {

            try
            {
                Expression expression = new Expression(richTextBox1.Text);
                Expression ex = new Expression(textBox1.Text);
                Expression exx = expression * ex;
                richTextBox2.Text = exx.ToString();
                History.Items.Add("(" + richTextBox1.Text + ") * (" + textBox1.Text + ") = " + richTextBox2.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void originalButtoncs8_ButtonClick(object sender, EventArgs e)
        {

            try
            {
                Expression expression = new Expression(richTextBox1.Text);

                KeyValuePair<double,double> exx = Expression.SolveforX(expression);
                richTextBox2.Text = exx.ToString();
                History.Items.Add("Solve(" + richTextBox1.Text + ")= " + richTextBox2.Text);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void originalButtoncs9_ButtonClick(object sender, EventArgs e)
        {

            try
            {
                Expression expression = new Expression(richTextBox1.Text);

                Expression exx = Expression.Differentiate(expression);
                richTextBox2.Text = exx.ToString();
                History.Items.Add("diff(" + richTextBox1.Text + ") = " + richTextBox2.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void originalButtoncs11_ButtonClick(object sender, EventArgs e)
        {
            try
            {
                Expression expression = new Expression(richTextBox1.Text);

                double exx = expression.Evaluate(Convert.ToDouble(textBox1.Text));
                richTextBox2.Text = exx.ToString();
                History.Items.Add(" (" + richTextBox1.Text + ") Evaluate (" + textBox1.Text + ") = " + richTextBox2.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    

        private void originalButtoncs4_ButtonClick_1(object sender, EventArgs e)
        {
            try
            {
                Expression expression = new Expression(richTextBox1.Text);

                Expression exx = expression ^ Convert.ToInt32(textBox1.Text) ;
                richTextBox2.Text = exx.ToString();
                History.Items.Add("(" + richTextBox1.Text + ") ^ (" + textBox1.Text + ") = " + richTextBox2.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            originalButtoncs1.Enabled = false;
            originalButtoncs2.Enabled =false;
            originalButtoncs3.Enabled = false;
            originalButtoncs4.Enabled = false;
            originalButtoncs5.Enabled = false;
            originalButtoncs11.Enabled = false;
            originalButtoncs8.Enabled = false;
            originalButtoncs9.Enabled =false;
            originalButtoncs10.Enabled = false;
            originalButtoncs7.Enabled = false;
            textBox1.Clear();
            richTextBox1.Clear();
            richTextBox2.Text = "";
            History.Items.Clear();
        }

        private void originalButtoncs10_ButtonClick(object sender, EventArgs e)
        {
            if (richTextBox1.Text.IndexOf('x')==0)
            {
                Graph graph = new Graph(this);
                graph.Show();
            }
            else
            { MessageBox.Show("input correct expression for Graph"); }


        }

        private void originalButtoncs5_ButtonClick(object sender, EventArgs e)
        {
            Expression e1= new Expression(richTextBox1.Text);
            Expression e2 = new Expression(textBox1.Text);
            Expression e3 = (e2 / e1).Item1;
            richTextBox2.Text = e3.ToString()+" "+(e2/e1).Item2;
            History.Items.Add("(" + richTextBox1.Text + ") / (" + textBox1.Text + ") = " + richTextBox2.Text);


        }


        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (richTextBox1.Text!="")
            {
                originalButtoncs1.Enabled = true;
                originalButtoncs2.Enabled = true;
                originalButtoncs3.Enabled = true;
                originalButtoncs4.Enabled = true;
                originalButtoncs5.Enabled = true;
                originalButtoncs11.Enabled = true;
                originalButtoncs8.Enabled = true;
                originalButtoncs9.Enabled = true;
                originalButtoncs10.Enabled = true;
                originalButtoncs7.Enabled = true;
            }
            else
            {
                originalButtoncs1.Enabled = false;
                originalButtoncs2.Enabled = false;
                originalButtoncs3.Enabled = false;
                originalButtoncs4.Enabled = false;
                originalButtoncs5.Enabled = false;
                originalButtoncs11.Enabled = false;
                originalButtoncs8.Enabled = false;
                originalButtoncs9.Enabled = false;
                originalButtoncs10.Enabled = false;
                originalButtoncs7.Enabled = false;
            }
          
        }

        private void originalButtoncs6_ButtonClick(object sender, EventArgs e)
        {
            string s = "", x = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";
            x += "<Expressions>";

            saveFileDialog1.Filter = "Text|*.txt";
            saveFileDialog1.Title = "Save Work";
            StreamWriter w;
            w = new StreamWriter(saveFileDialog1.FileName);
            for (int i = 0; i < History.Items.Count; i++)
            {
                x += "<Expression ";
                s = History.Items[i].ToString();
                string[] a = s.Split('=');
                if (a[0].Contains(") + ("))
                {
                    string[] v = a[0].Split(new string[] { " + " }, StringSplitOptions.None);
                    x += $"userExpression1 ='{v[0]}' operation= 'Addition' " + $" userExpression2= '{v[1]}'";
                }
                else if (a[0].Contains(") - ("))
                {
                    string[] v = a[0].Split(new string[] { " - " }, StringSplitOptions.None);
                    x += $"userExpression1 ='{v[0]}' operation='Subtraction' " + $" userExpression2='{v[1]}'";
                }
                else if (a[0].Contains(") * ("))
                {
                    string[] v = a[0].Split(new string[] { " * " }, StringSplitOptions.None);
                    x += $"userExpression1 ='{v[0]}' operation='Multiplication' " + $" userExpression2='{v[1]}'";
                }
                else if (a[0].Contains(") / ("))
                {
                    string[] v = a[0].Split(new string[] { " / " }, StringSplitOptions.None);
                    x += $"userExpression1 ='{v[0]}' operation='Division' " + $" userExpression2='{v[1]}'";
                }
                else if (a[0].Contains(") Evaluate ("))
                {
                    string[] v = a[0].Split(new string[] { " Evaluate " }, StringSplitOptions.None);
                    x += $"userExpression1 ='{v[0]}' operation='Evaluation' " + $" userExpression2='{v[1]}'";
                }
                else if (a[0].Contains("diff"))
                {
                    string[] v = a[0].Split(new string[] { "diff" }, StringSplitOptions.None);
                    x += $"userExpression1 ='{v[1]}' operation='Differentiation' " + $" userExpression2=' '";
                }
                else if (a[0].Contains(") ^ ("))
                {
                    string[] v = a[0].Split(new string[] { " ^ " }, StringSplitOptions.None);
                    x += $"userExpression1 ='{v[0]}' operation='Power' " + $" userExpression2='{v[1]}'";
                }

                else if (a[0].Contains("Solve"))
                {
                    string[] v = a[0].Split(new string[] { "Solve" }, StringSplitOptions.None);
                    x += $"userExpression1 ='{v[1]}' operation='Solving' " + $" userExpression2=' '";
                }
                else if (a[0].Contains("integ"))
                {
                    string[] v = a[0].Split(new string[] { "integ" }, StringSplitOptions.None);
                    x += $"userExpression1 ='{v[1]}' operation='Integral' " + $" userExpression2=' '";
                }

                x += " Output='" + a[1] + "'";
                x += "> </Expression>";
                x += Environment.NewLine;


            }
            x += "</Expressions>";
            w.Write(x);
            w.Close();


        }

        private void originalButtoncs5_Load(object sender, EventArgs e)
        {

        }

        private void originalButtoncs7_ButtonClick(object sender, EventArgs e)
        {
            try
            {
                Expression expression = new Expression(richTextBox1.Text);

                Expression exx = Expression.Integrate(expression);
                richTextBox2.Text = exx.ToString();
                History.Items.Add("integ(" + richTextBox1.Text + ") = " + richTextBox2.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
