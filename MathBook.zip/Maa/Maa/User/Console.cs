﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using System.Xml;
using System.IO;

namespace Maa
{
    public partial class Console : UserControl
    {
        FastColoredTextBox a;
        public Console()
        {
            InitializeComponent();
        }
        TextStyle classes = new TextStyle(Brushes.Green, null, FontStyle.Bold);
        TextStyle keyword = new TextStyle(Brushes.Blue, null, FontStyle.Regular);
        private void Console_Load(object sender, EventArgs e)
        {
            a = new FastColoredTextBox();
            a.TextChanged += A_TextChanged;
            a.Dock = DockStyle.Fill;
            panel1.Controls.Add(a);
            a.LineNumberColor = Color.DarkBlue;
            a.BackColor = Color.Transparent;
            a.KeyDown += A_KeyDown1;
            
        }

        private void A_TextChanged(object sender, TextChangedEventArgs e)
        {
            e.ChangedRange.ClearStyle(classes);
            for (int i = 0; i < Language.classes.Length; i++)
            {
                e.ChangedRange.SetStyle(classes, Language.classes[i]);
            }
            e.ChangedRange.ClearStyle(keyword);
            for (int j = 0; j < Language.keyword.Length; j++)
            {
                e.ChangedRange.SetStyle(keyword, Language.keyword[j]);
            }
           
        }

        private void A_KeyDown1(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                Result.Text = "";
                for (int i = 0; i < a.LinesCount; i++)
                {
                    if (a.GetLineText(i) != "" )
                    {
                        try
                        {
                            string s = a.GetLineText(i);
                            Language language = new Language();
                            string ss = language.Readsyntax(s);
                            Result.Text += i == 0 ? ss : "," + ss;
                        }
                        catch(Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
                
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Result.Text = "";
            for (int i = 0; i < a.LinesCount; i++)
            {
                if (a.GetLineText(i) != "")
                {try
                    {
                        string s = a.GetLineText(i);
                        Language language = new Language();
                        string ss = language.Readsyntax(s);
                        Result.Text += i == 0 ? ss : "," + ss;

                    }
                    catch ( Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();

        }
        bool Hided = true;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Hided == true)
            {
                panel4.Width = panel4.Width + 10;
                if (panel4.Width >= 148)
                {
                    timer1.Stop();
                    Hided = false;

                }
            }
            else
            {
                panel4.Width = panel4.Width - 10;
                if (panel4.Width <= 0)
                {
                    timer1.Stop();
                    Hided = true;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text|*.txt";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    XmlWriter w = XmlWriter.Create(saveFileDialog1.FileName);
                    w.WriteStartDocument();
                    w.WriteStartElement("Expressions");
                    for (int i = 0; i < a.LinesCount && a.GetLineText(i) != ""; i++)
                    {
                        string[] classs = a.GetLineText(i).Split(' ');
                        string[] ap = classs[1].Split('.');
                        string[] v = ap[1].Split(',');
                        w.WriteStartElement("Expression");
                        w.WriteAttributeString("userexpression1", v[0]);
                        w.WriteAttributeString("operation", ap[0]);
                        w.WriteAttributeString("userexpression2", v[1]);
                        string[] r = Result.Text.Split(',');
                        w.WriteAttributeString("Result", r[i]);
                        w.WriteEndElement();

                    }
                    w.WriteEndElement();
                    w.WriteEndDocument();
                    w.Close();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "MathsApp|*.Math";saveFileDialog1.Title = "Save Console";
            if (saveFileDialog1.ShowDialog()==DialogResult.OK)
            {
                StreamWriter s = new StreamWriter(saveFileDialog1.FileName);
                s.Write(a.Text);
                s.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "MathsApp|*.Math";openFileDialog1.Title = "Open Console";
            if (openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                StreamReader streamReader = new StreamReader(openFileDialog1.FileName);
                a.Text=streamReader.ReadToEnd();
                streamReader.Close();

            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
