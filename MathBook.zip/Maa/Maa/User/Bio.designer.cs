﻿namespace Maa
{
    partial class Bio
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.originalButtoncs5 = new Maa.OriginalButtoncs();
            this.originalButtoncs6 = new Maa.OriginalButtoncs();
            this.originalButtoncs7 = new Maa.OriginalButtoncs();
            this.originalButtoncs8 = new Maa.OriginalButtoncs();
            this.originalButtoncs1 = new Maa.OriginalButtoncs();
            this.originalButtoncs3 = new Maa.OriginalButtoncs();
            this.originalButtoncs2 = new Maa.OriginalButtoncs();
            this.originalButtoncs4 = new Maa.OriginalButtoncs();
            this.originalButtoncs9 = new Maa.OriginalButtoncs();
            this.originalButtoncs10 = new Maa.OriginalButtoncs();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.History = new System.Windows.Forms.ListBox();
            this.originalButtoncs11 = new Maa.OriginalButtoncs();
            this.label3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Constantia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(433, 501);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 33);
            this.button1.TabIndex = 11;
            this.button1.Text = "Clear All";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Californian FB", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(161, 98);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(324, 35);
            this.textBox1.TabIndex = 10;
            this.textBox1.Text = "Number Of Terms(n)";
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bell MT", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(70, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 42);
            this.label2.TabIndex = 8;
            this.label2.Text = "Output";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bell MT", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(357, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 42);
            this.label1.TabIndex = 9;
            this.label1.Text = "User Expression";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox1.Font = new System.Drawing.Font("Californian FB", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(333, 62);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(324, 40);
            this.richTextBox1.TabIndex = 7;
            this.richTextBox1.Text = "Expression";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            this.richTextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.richTextBox1_KeyPress);
            // 
            // originalButtoncs5
            // 
            this.originalButtoncs5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.originalButtoncs5.Enabled = false;
            this.originalButtoncs5.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs5.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs5.Location = new System.Drawing.Point(502, 362);
            this.originalButtoncs5.Name = "originalButtoncs5";
            this.originalButtoncs5.Size = new System.Drawing.Size(193, 56);
            this.originalButtoncs5.Sizee = new System.Drawing.Size(162, 56);
            this.originalButtoncs5.TabIndex = 13;
            this.originalButtoncs5.txt = "Sum Of Coefficients";
            this.originalButtoncs5.ButtonClick += new Maa.ButtonClick(this.originalButtoncs5_ButtonClick);
            // 
            // originalButtoncs6
            // 
            this.originalButtoncs6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.originalButtoncs6.Enabled = false;
            this.originalButtoncs6.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs6.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs6.Location = new System.Drawing.Point(503, 436);
            this.originalButtoncs6.Name = "originalButtoncs6";
            this.originalButtoncs6.Size = new System.Drawing.Size(192, 56);
            this.originalButtoncs6.Sizee = new System.Drawing.Size(161, 56);
            this.originalButtoncs6.TabIndex = 13;
            this.originalButtoncs6.txt = "Sum Of Odd Coefficients";
            this.originalButtoncs6.ButtonClick += new Maa.ButtonClick(this.originalButtoncs6_ButtonClick);
            // 
            // originalButtoncs7
            // 
            this.originalButtoncs7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.originalButtoncs7.Enabled = false;
            this.originalButtoncs7.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs7.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs7.Location = new System.Drawing.Point(277, 285);
            this.originalButtoncs7.Name = "originalButtoncs7";
            this.originalButtoncs7.Size = new System.Drawing.Size(193, 56);
            this.originalButtoncs7.Sizee = new System.Drawing.Size(162, 56);
            this.originalButtoncs7.TabIndex = 12;
            this.originalButtoncs7.txt = "Binomial Expansion";
            this.originalButtoncs7.ButtonClick += new Maa.ButtonClick(this.originalButtoncs7_ButtonClick);
            // 
            // originalButtoncs8
            // 
            this.originalButtoncs8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.originalButtoncs8.Enabled = false;
            this.originalButtoncs8.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs8.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs8.Location = new System.Drawing.Point(502, 285);
            this.originalButtoncs8.Name = "originalButtoncs8";
            this.originalButtoncs8.Size = new System.Drawing.Size(193, 56);
            this.originalButtoncs8.Sizee = new System.Drawing.Size(162, 56);
            this.originalButtoncs8.TabIndex = 12;
            this.originalButtoncs8.txt = "Mid Term ";
            this.originalButtoncs8.ButtonClick += new Maa.ButtonClick(this.originalButtoncs8_ButtonClick);
            // 
            // originalButtoncs1
            // 
            this.originalButtoncs1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.originalButtoncs1.Enabled = false;
            this.originalButtoncs1.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs1.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs1.Location = new System.Drawing.Point(502, 214);
            this.originalButtoncs1.Name = "originalButtoncs1";
            this.originalButtoncs1.Size = new System.Drawing.Size(193, 56);
            this.originalButtoncs1.Sizee = new System.Drawing.Size(162, 56);
            this.originalButtoncs1.TabIndex = 12;
            this.originalButtoncs1.txt = "Required Term";
            this.originalButtoncs1.ButtonClick += new Maa.ButtonClick(this.originalButtoncs1_ButtonClick);
            // 
            // originalButtoncs3
            // 
            this.originalButtoncs3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.originalButtoncs3.Enabled = false;
            this.originalButtoncs3.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs3.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs3.Location = new System.Drawing.Point(277, 362);
            this.originalButtoncs3.Name = "originalButtoncs3";
            this.originalButtoncs3.Size = new System.Drawing.Size(196, 56);
            this.originalButtoncs3.Sizee = new System.Drawing.Size(165, 56);
            this.originalButtoncs3.TabIndex = 12;
            this.originalButtoncs3.txt = "Term Independed Of X";
            this.originalButtoncs3.ButtonClick += new Maa.ButtonClick(this.originalButtoncs3_ButtonClick);
            // 
            // originalButtoncs2
            // 
            this.originalButtoncs2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.originalButtoncs2.Enabled = false;
            this.originalButtoncs2.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs2.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs2.Location = new System.Drawing.Point(277, 436);
            this.originalButtoncs2.Name = "originalButtoncs2";
            this.originalButtoncs2.Size = new System.Drawing.Size(197, 56);
            this.originalButtoncs2.Sizee = new System.Drawing.Size(166, 56);
            this.originalButtoncs2.TabIndex = 13;
            this.originalButtoncs2.txt = "Sum Of Even Coefficients";
            this.originalButtoncs2.ButtonClick += new Maa.ButtonClick(this.originalButtoncs2_ButtonClick);
            // 
            // originalButtoncs4
            // 
            this.originalButtoncs4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.originalButtoncs4.Enabled = false;
            this.originalButtoncs4.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs4.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs4.Location = new System.Drawing.Point(277, 214);
            this.originalButtoncs4.Name = "originalButtoncs4";
            this.originalButtoncs4.Size = new System.Drawing.Size(193, 56);
            this.originalButtoncs4.Sizee = new System.Drawing.Size(162, 56);
            this.originalButtoncs4.TabIndex = 12;
            this.originalButtoncs4.txt = "nPr";
            this.originalButtoncs4.ButtonClick += new Maa.ButtonClick(this.originalButtoncs4_ButtonClick);
            // 
            // originalButtoncs9
            // 
            this.originalButtoncs9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.originalButtoncs9.Enabled = false;
            this.originalButtoncs9.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs9.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs9.Location = new System.Drawing.Point(502, 152);
            this.originalButtoncs9.Name = "originalButtoncs9";
            this.originalButtoncs9.Size = new System.Drawing.Size(193, 56);
            this.originalButtoncs9.Sizee = new System.Drawing.Size(162, 56);
            this.originalButtoncs9.TabIndex = 12;
            this.originalButtoncs9.txt = "nCr";
            this.originalButtoncs9.ButtonClick += new Maa.ButtonClick(this.originalButtoncs9_ButtonClick);
            // 
            // originalButtoncs10
            // 
            this.originalButtoncs10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.originalButtoncs10.Enabled = false;
            this.originalButtoncs10.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs10.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs10.Location = new System.Drawing.Point(277, 152);
            this.originalButtoncs10.Name = "originalButtoncs10";
            this.originalButtoncs10.Size = new System.Drawing.Size(193, 56);
            this.originalButtoncs10.Sizee = new System.Drawing.Size(162, 56);
            this.originalButtoncs10.TabIndex = 12;
            this.originalButtoncs10.txt = "Factorial";
            this.originalButtoncs10.ButtonClick += new Maa.ButtonClick(this.originalButtoncs10_ButtonClick);
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Californian FB", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(481, 98);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(324, 35);
            this.textBox2.TabIndex = 10;
            this.textBox2.Text = "Required Term(r)";
            this.textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // History
            // 
            this.History.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.History.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.History.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.History.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.History.ForeColor = System.Drawing.Color.White;
            this.History.FormattingEnabled = true;
            this.History.ItemHeight = 19;
            this.History.Location = new System.Drawing.Point(810, 151);
            this.History.Name = "History";
            this.History.Size = new System.Drawing.Size(295, 95);
            this.History.TabIndex = 15;
            this.History.SelectedValueChanged += new System.EventHandler(this.History_SelectedValueChanged);
            // 
            // originalButtoncs11
            // 
            this.originalButtoncs11.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.originalButtoncs11.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs11.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs11.Location = new System.Drawing.Point(869, 271);
            this.originalButtoncs11.Name = "originalButtoncs11";
            this.originalButtoncs11.Size = new System.Drawing.Size(162, 60);
            this.originalButtoncs11.Sizee = new System.Drawing.Size(131, 60);
            this.originalButtoncs11.TabIndex = 16;
            this.originalButtoncs11.txt = "Save Work";
            this.originalButtoncs11.ButtonClick += new Maa.ButtonClick(this.originalButtoncs11_ButtonClick);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.Font = new System.Drawing.Font("Bell MT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(44, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 38);
            this.label3.TabIndex = 17;
            // 
            // Bio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.originalButtoncs11);
            this.Controls.Add(this.History);
            this.Controls.Add(this.originalButtoncs2);
            this.Controls.Add(this.originalButtoncs6);
            this.Controls.Add(this.originalButtoncs5);
            this.Controls.Add(this.originalButtoncs3);
            this.Controls.Add(this.originalButtoncs8);
            this.Controls.Add(this.originalButtoncs7);
            this.Controls.Add(this.originalButtoncs9);
            this.Controls.Add(this.originalButtoncs10);
            this.Controls.Add(this.originalButtoncs4);
            this.Controls.Add(this.originalButtoncs1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextBox1);
            this.DoubleBuffered = true;
            this.Name = "Bio";
            this.Size = new System.Drawing.Size(1112, 535);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private OriginalButtoncs originalButtoncs5;
        private OriginalButtoncs originalButtoncs6;
        private OriginalButtoncs originalButtoncs7;
        private OriginalButtoncs originalButtoncs8;
        private OriginalButtoncs originalButtoncs1;
        private OriginalButtoncs originalButtoncs3;
        private OriginalButtoncs originalButtoncs2;
        private OriginalButtoncs originalButtoncs4;
        private OriginalButtoncs originalButtoncs9;
        private OriginalButtoncs originalButtoncs10;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ListBox History;
        private OriginalButtoncs originalButtoncs11;
        private System.Windows.Forms.TextBox label3;
    }
}
