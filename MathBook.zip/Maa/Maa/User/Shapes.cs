﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Maa
{
    public partial class Shapes : UserControl
    {
        double s;
        bool isCicle, isSquare, isRectangle, isTriangle, isPara, isCircular, isRectangular, isCirRing, isSphere, isTrepezoid, isRightCircularCone, isCube, isCylinder;

        private void originalButtoncs12_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true; textBox2.Visible = true; Done.Visible = true;
            textBox1.Text = "Radius"; textBox2.Text = "Height"; textBox3.Visible = false; textBox4.Visible = false;
            isCicle = false; isSquare = false; isRectangle = false; isTriangle = false; isPara = false; isCircular = false;
            isRectangular = false;
            isCirRing = false; isSphere = false; isTrepezoid = false;
            isRightCircularCone = true; isCube = false; isCylinder = false;
        }

        private void originalButtoncs13_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true; textBox2.Visible = false; Done.Visible = true;
            textBox1.Text = "Length"; textBox3.Visible = false; textBox4.Visible = false; 
            isCicle = false; isSquare = false; isRectangle = false; isTriangle = false; isPara = false; isCircular = false;
            isRectangular = false;
            isCirRing = false; isSphere = false; isTrepezoid = false;
            isRightCircularCone = false; isCube = true; isCylinder = false;
        }

        private void originalButtoncs14_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true; textBox2.Visible = true; Done.Visible = true;
            textBox1.Text = "Radius"; textBox2.Text = "Height"; textBox3.Visible = false; textBox4.Visible = false; 
            isCicle = false; isSquare = false; isRectangle = false; isTriangle = false; isPara = false; isCircular = false;
            isRectangular = false;
            isCirRing = false; isSphere = false; isTrepezoid = false;
            isRightCircularCone = false; isCube = false; isCylinder = true;
        }

        private void originalButtoncs7_ButtonClick(object sender, EventArgs e)
        {  
            using (SaveFileDialog a = new SaveFileDialog())
            {a.Filter= "M|*.Math|Text|*.txt";
                if (a.ShowDialog() == DialogResult.OK)
                {
                    XmlWriter x = XmlWriter.Create(a.FileName);
                    x.WriteStartDocument();
                    x.WriteStartElement("Expressions");
                    for (int i = 0; i < History.Items.Count; i++)
                    {
                      string[] s = History.Items[i].ToString().Split('|');
                      x.WriteStartElement("Expression");
                      x.WriteAttributeString("userexpression1", s[0]);
                      x.WriteAttributeString("operation", "Solving");
                      x.WriteAttributeString("userexpression2", s[1]);
                      x.WriteAttributeString("Result", s[2]);
                      x.WriteEndElement();

                    }
                    x.WriteEndElement();
                    x.WriteEndDocument();
                    x.Close();
                }
                
            }
        }

        private void History_SelectedValueChanged(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(History, History.SelectedItem.ToString());
        }

        private void Shapes_Load(object sender, EventArgs e)
        {

        }

        private void originalButtoncs11_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true; textBox2.Visible = true; Done.Visible = true;
            textBox1.Text = "Top"; textBox2.Text = "Base";textBox3.Text = "c";textBox4.Text = "d"; textBox3.Visible = true; textBox4.Visible = true;
            isCicle = false; isSquare = false; isRectangle = false; isTriangle = false; isPara = false; isCircular = false;
            isRectangular = false;
            isCirRing = false; isSphere = false; isTrepezoid = true;
            isRightCircularCone = false; isCube = false; isCylinder = false;
        }

        private void originalButtoncs10_ButtonClick(object sender, EventArgs e)
        {

            textBox1.Visible = true; textBox2.Visible = false; Done.Visible = true;
            textBox1.Text = "Radius";  textBox3.Visible = false; textBox4.Visible = false;  
            isCicle = false; isSquare = false; isRectangle = false; isTriangle = false; isPara = false; isCircular = false;
            isRectangular = false;
            isCirRing = false; isSphere = true; isTrepezoid = false;
            isRightCircularCone = false; isCube = false; isCylinder = false;
        }

        private void originalButtoncs9_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true; textBox2.Visible = true; Done.Visible = true;
            textBox1.Text = "r"; textBox2.Text = "R"; textBox3.Visible = false; textBox4.Visible = false; 
            isCicle = false; isSquare = false; isRectangle = false; isTriangle = false; isPara = false; isCircular = false;
            isRectangular = false;
            isCirRing = true; isSphere = false; isTrepezoid = false;
            isRightCircularCone = false; isCube = false; isCylinder = false;
        }

        private void originalButtoncs8_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true; textBox2.Visible = true; Done.Visible = true;
            textBox1.Text = "Height"; textBox2.Text = "Breadth"; textBox3.Visible = true;textBox3.Text = "Width"; textBox4.Visible = false;  
            isCicle = false; isSquare = false; isRectangle = false; isTriangle = false; isPara = false; isCircular = false;
            isRectangular = true;
            isCirRing = false; isSphere = false; isTrepezoid = false;
            isRightCircularCone = false; isCube = false; isCylinder = false;
        }

        private void originalButtoncs6_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true; textBox2.Visible = true; Done.Visible = true;
            textBox1.Text = "Radius"; textBox2.Text = "Theta"; textBox3.Visible = false;  textBox4.Visible = false; 
            isCicle = false; isSquare = false; isRectangle = false; isTriangle = false; isPara = false; isCircular = true;
            isRectangular = false;
            isCirRing = false; isSphere = false; isTrepezoid = false;
            isRightCircularCone = false; isCube = false; isCylinder = false;
        }

        private void originalButtoncs5_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true; textBox2.Visible = true; Done.Visible = true;
            textBox1.Text = "Length"; textBox2.Text = "Breadth"; textBox3.Visible = true;textBox3.Text = "Height"; textBox4.Visible = false;
            isCicle = false; isSquare = false; isRectangle = false; isTriangle = false; isPara = true; isCircular = false;
            isRectangular = false;
            isCirRing = false; isSphere = false; isTrepezoid = false;
            isRightCircularCone = false; isCube = false; isCylinder = false;
        }

        private void originalButtoncs4_ButtonClick(object sender, EventArgs e)
        {
            Done.Visible = true;
            textBox1.Text = "a";textBox2.Text = "Breadth"; textBox3.Text = "c";textBox4.Text = "Height";textBox1.Visible = true; textBox2.Visible = true; textBox3.Visible = true; textBox4.Visible = true;
            isCicle = false; isSquare = false; isRectangle = false; isTriangle = true; isPara = false; isCircular = false;
            isRectangular = false;
            isCirRing = false; isSphere = false; isTrepezoid = false;
            isRightCircularCone = false; isCube = false; isCylinder = false;
        }

        private void originalButtoncs3_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true;textBox2.Visible = true; Done.Visible = true; 
            textBox1.Text = "Length";textBox2.Text = "Breadth";textBox3.Visible = false;textBox4.Visible = false;
            isCicle = false; isSquare = false; isRectangle = true; isTriangle = false; isPara = false; isCircular = false;
            isRectangular = false;
            isCirRing = false; isSphere = false; isTrepezoid = false;
            isRightCircularCone = false; isCube = false; isCylinder = false;
        }

        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true; textBox2.Visible = false; Done.Visible = true; 
            textBox1.Text = "Length"; textBox3.Visible = false; textBox4.Visible = false;
            isCicle = false; isSquare = true; isRectangle = false; isTriangle = false; isPara = false; isCircular = false;
            isRectangular = false;
            isCirRing = false; isSphere = false; isTrepezoid = false;
            isRightCircularCone = false; isCube = false; isCylinder = false;
        }

        private void Done_Click(object sender, EventArgs e)
        {
            double a, b, c, d;
            if (textBox1.Text == "") { a = 0;  } else { a = Convert.ToDouble(textBox1.Text); }
            if (textBox2.Text == "") { b = 0; } else { b = Convert.ToDouble(textBox2.Text); }
                if (textBox3.Text == "") { c = 0;  } else { c = Convert.ToDouble(textBox3.Text); }
            if (textBox4.Text == "") { d = 0; } else { d = Convert.ToDouble(textBox4.Text); }
            if (isCicle==true)
            { 
                result.Text = $"Perimeter={2*3.14*Convert.ToDouble(textBox1.Text)} Area={3.14*(Convert.ToDouble(textBox1.Text))* Convert.ToDouble(textBox1.Text)}";
                History.Items.Add($"Circle|Radius({textBox1.Text})|{result.Text}");
            }
            else if(isRectangle==true)
            {
                result.Text = $"Perimeter={(2 * Convert.ToDouble(textBox1.Text)) + (2 * Convert.ToDouble(textBox2.Text))} Area={Convert.ToDouble(textBox1.Text) * Convert.ToDouble(textBox2.Text)}";
                History.Items.Add($"Rectangle|Length({textBox1.Text})|{result.Text}");
            }
            else if(isSquare)
            {
                result.Text = $"Perimeter={4 * Convert.ToDouble(textBox1.Text)}\n Area={(Convert.ToDouble(textBox1.Text)) * Convert.ToDouble(textBox1.Text)}";
                History.Items.Add($"Sqaure|Length({textBox1.Text})|{result.Text}");
            }
            else if(isTriangle)
            {
                result.Text = $"Perimeter={Convert.ToDouble(textBox2.Text) * Convert.ToDouble(textBox3.Text) * Convert.ToDouble(textBox1.Text)}\n Area={0.5 * (Convert.ToDouble(textBox2.Text)) * Convert.ToDouble(textBox4.Text)}";
                History.Items.Add($"Triangle|a({textBox1.Text})Breadth({textBox2.Text})c({textBox3.Text})Height({textBox4.Text})" +
                    $"|{result.Text}");
            }
            else if(isPara)
            {
                result.Text = $"Perimeter={(2 * Convert.ToDouble(textBox1.Text)) + (2 * Convert.ToDouble(textBox2.Text))} Area={Convert.ToDouble(textBox2.Text) * Convert.ToDouble(textBox3.Text)}";
                History.Items.Add($"Paralellogram|Length({textBox1.Text})Breadth({textBox2.Text})Height({textBox3.Text})|{result.Text}");
            }
            else if(isCircular)
            {
                result.Text = $"Length={(3.16 * Convert.ToDouble(textBox1.Text)) * ( Convert.ToDouble(textBox2.Text)/180)} Area={3.16 * Convert.ToDouble(textBox1.Text)* Convert.ToDouble(textBox1.Text) * (Convert.ToDouble(textBox2.Text) / 360)}";
                History.Items.Add($"CircularSector|Radius({textBox1.Text})Theta({textBox2.Text})|{result.Text}");
            }
            else if(isRectangular)
            {
                result.Text = $"Area={(2 * Convert.ToDouble(textBox1.Text )* Convert.ToDouble(textBox2.Text)) +( 2 *Convert.ToDouble(textBox1.Text) * Convert.ToDouble(textBox3.Text)) + (2 * Convert.ToDouble(textBox2.Text) * Convert.ToDouble(textBox3.Text))}" +
                    $" Volume={Convert.ToDouble(textBox1.Text)*Convert.ToDouble(textBox2.Text)*Convert.ToDouble(textBox3.Text)}";
                History.Items.Add($"RectangularBox|Height({textBox1.Text})Breadth({textBox2.Text})Width({textBox3.Text})|{result.Text}");
            }
            else if(isCirRing)
            {
                result.Text = $"Area={3.14*((b*b)-(a*a))}";
                History.Items.Add($"CircularRing|r({textBox1.Text})R({textBox2.Text})|{result.Text}");
            }
            else if(isSphere)
            {
               result.Text= $"S={4 * 3.14 * a * a} Volume={(4 * 3.14 * a * a * a)/3} ";
                History.Items.Add($"Sphere|Radius({textBox1.Text})|{result.Text}");
            }
            else if(isTrepezoid)
            {
                result.Text = $"Perimeter{a+b+c+d} Area={d*((a+b)/2)}";
                History.Items.Add($"Trepozoid|Top({textBox1.Text})Base({textBox2.Text})c({textBox3.Text})d({textBox4.Text})|{result.Text}");
            }
            else if(isRightCircularCone)
            {
                s = Math.Pow((double)(a * a) + (double)(b * b), 1/2);
                result.Text = $"Area={((22/7)*a*a)+((22/7)*a*s)} S={s} Volume={(1/3)*(22/7)*a*a*b}";
                History.Items.Add($"RightCircularCone|Radius({textBox1.Text})Height({textBox2.Text})|{result.Text}");
            }
            else if(isCube)
            {
                result.Text = $"Area={6*a*a} Volume={a*a*a}";
                History.Items.Add($"Cube|Length({textBox1.Text})|{result.Text}");
            }
                else if(isCylinder)
            {
                result.Text = $"Area={(2*(22/7)*a)*(a+b)} Volume={(22/7)*(a*a)*b} ";
                History.Items.Add($"Cylinder|Radius({textBox1.Text})Height({textBox2.Text})|{result.Text}");
            }
        }

        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            textBox1.Visible = true; textBox2.Visible = false; Done.Visible = true;
            textBox1.Text = "Radius"; textBox3.Visible = false; textBox4.Visible = false;
            isCicle = true;isSquare = false;isRectangle = false;isTriangle = false;isPara = false;isCircular = false;
            isRectangular = false;
            isCirRing = false;isSphere = false;isTrepezoid = false;
            isRightCircularCone = false;isCube = false;isCylinder = false;
        }

        public Shapes()
        {
            InitializeComponent();
        }
    }
}
