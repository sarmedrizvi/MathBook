﻿namespace Maa
{
    partial class Shapes
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.output = new System.Windows.Forms.Label();
            this.result = new System.Windows.Forms.Label();
            this.Done = new System.Windows.Forms.Button();
            this.History = new System.Windows.Forms.ListBox();
            this.originalButtoncs7 = new Maa.OriginalButtoncs();
            this.originalButtoncs14 = new Maa.OriginalButtoncs();
            this.originalButtoncs13 = new Maa.OriginalButtoncs();
            this.originalButtoncs12 = new Maa.OriginalButtoncs();
            this.originalButtoncs11 = new Maa.OriginalButtoncs();
            this.originalButtoncs10 = new Maa.OriginalButtoncs();
            this.originalButtoncs9 = new Maa.OriginalButtoncs();
            this.originalButtoncs8 = new Maa.OriginalButtoncs();
            this.originalButtoncs6 = new Maa.OriginalButtoncs();
            this.originalButtoncs5 = new Maa.OriginalButtoncs();
            this.originalButtoncs4 = new Maa.OriginalButtoncs();
            this.originalButtoncs3 = new Maa.OriginalButtoncs();
            this.originalButtoncs2 = new Maa.OriginalButtoncs();
            this.originalButtoncs1 = new Maa.OriginalButtoncs();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Californian FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(400, 111);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(248, 32);
            this.textBox1.TabIndex = 12;
            this.textBox1.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Californian FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(400, 147);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(248, 32);
            this.textBox2.TabIndex = 12;
            this.textBox2.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Font = new System.Drawing.Font("Californian FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(400, 188);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(248, 32);
            this.textBox3.TabIndex = 12;
            this.textBox3.Visible = false;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Font = new System.Drawing.Font("Californian FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(400, 225);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(248, 32);
            this.textBox4.TabIndex = 12;
            this.textBox4.Visible = false;
            // 
            // output
            // 
            this.output.AutoSize = true;
            this.output.Font = new System.Drawing.Font("Bell MT", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.output.Location = new System.Drawing.Point(454, 312);
            this.output.Name = "output";
            this.output.Size = new System.Drawing.Size(126, 42);
            this.output.TabIndex = 13;
            this.output.Text = "output";
            // 
            // result
            // 
            this.result.AutoSize = true;
            this.result.Font = new System.Drawing.Font("Californian FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result.Location = new System.Drawing.Point(437, 352);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(0, 24);
            this.result.TabIndex = 14;
            // 
            // Done
            // 
            this.Done.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Done.Font = new System.Drawing.Font("Chiller", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Done.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Done.Location = new System.Drawing.Point(475, 262);
            this.Done.Name = "Done";
            this.Done.Size = new System.Drawing.Size(81, 40);
            this.Done.TabIndex = 15;
            this.Done.Text = "Done";
            this.Done.UseVisualStyleBackColor = true;
            this.Done.Visible = false;
            this.Done.Click += new System.EventHandler(this.Done_Click);
            // 
            // History
            // 
            this.History.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.History.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.History.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.History.Font = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.History.ForeColor = System.Drawing.Color.White;
            this.History.FormattingEnabled = true;
            this.History.ItemHeight = 18;
            this.History.Location = new System.Drawing.Point(388, 390);
            this.History.Name = "History";
            this.History.Size = new System.Drawing.Size(284, 92);
            this.History.TabIndex = 17;
            this.History.SelectedValueChanged += new System.EventHandler(this.History_SelectedValueChanged);
            // 
            // originalButtoncs7
            // 
            this.originalButtoncs7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.originalButtoncs7.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs7.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs7.Location = new System.Drawing.Point(445, 504);
            this.originalButtoncs7.Name = "originalButtoncs7";
            this.originalButtoncs7.Size = new System.Drawing.Size(152, 48);
            this.originalButtoncs7.Sizee = new System.Drawing.Size(121, 48);
            this.originalButtoncs7.TabIndex = 18;
            this.originalButtoncs7.txt = "Save Work";
            this.originalButtoncs7.ButtonClick += new Maa.ButtonClick(this.originalButtoncs7_ButtonClick);
            // 
            // originalButtoncs14
            // 
            this.originalButtoncs14.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs14.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs14.Location = new System.Drawing.Point(0, 377);
            this.originalButtoncs14.Name = "originalButtoncs14";
            this.originalButtoncs14.Size = new System.Drawing.Size(167, 56);
            this.originalButtoncs14.Sizee = new System.Drawing.Size(136, 56);
            this.originalButtoncs14.TabIndex = 0;
            this.originalButtoncs14.txt = "Cylinder";
            this.originalButtoncs14.ButtonClick += new Maa.ButtonClick(this.originalButtoncs14_ButtonClick);
            // 
            // originalButtoncs13
            // 
            this.originalButtoncs13.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs13.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs13.Location = new System.Drawing.Point(904, 218);
            this.originalButtoncs13.Name = "originalButtoncs13";
            this.originalButtoncs13.Size = new System.Drawing.Size(167, 63);
            this.originalButtoncs13.Sizee = new System.Drawing.Size(136, 63);
            this.originalButtoncs13.TabIndex = 0;
            this.originalButtoncs13.txt = "Cube";
            this.originalButtoncs13.ButtonClick += new Maa.ButtonClick(this.originalButtoncs13_ButtonClick);
            // 
            // originalButtoncs12
            // 
            this.originalButtoncs12.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs12.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs12.Location = new System.Drawing.Point(867, 149);
            this.originalButtoncs12.Name = "originalButtoncs12";
            this.originalButtoncs12.Size = new System.Drawing.Size(204, 63);
            this.originalButtoncs12.Sizee = new System.Drawing.Size(173, 63);
            this.originalButtoncs12.TabIndex = 0;
            this.originalButtoncs12.txt = "Right Circular Cone";
            this.originalButtoncs12.ButtonClick += new Maa.ButtonClick(this.originalButtoncs12_ButtonClick);
            // 
            // originalButtoncs11
            // 
            this.originalButtoncs11.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs11.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs11.Location = new System.Drawing.Point(904, 85);
            this.originalButtoncs11.Name = "originalButtoncs11";
            this.originalButtoncs11.Size = new System.Drawing.Size(167, 63);
            this.originalButtoncs11.Sizee = new System.Drawing.Size(136, 63);
            this.originalButtoncs11.TabIndex = 0;
            this.originalButtoncs11.txt = "Trapezoid";
            this.originalButtoncs11.ButtonClick += new Maa.ButtonClick(this.originalButtoncs11_ButtonClick);
            // 
            // originalButtoncs10
            // 
            this.originalButtoncs10.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs10.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs10.Location = new System.Drawing.Point(904, 16);
            this.originalButtoncs10.Name = "originalButtoncs10";
            this.originalButtoncs10.Size = new System.Drawing.Size(167, 63);
            this.originalButtoncs10.Sizee = new System.Drawing.Size(136, 63);
            this.originalButtoncs10.TabIndex = 0;
            this.originalButtoncs10.txt = "Sphere";
            this.originalButtoncs10.ButtonClick += new Maa.ButtonClick(this.originalButtoncs10_ButtonClick);
            // 
            // originalButtoncs9
            // 
            this.originalButtoncs9.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs9.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs9.Location = new System.Drawing.Point(0, 502);
            this.originalButtoncs9.Name = "originalButtoncs9";
            this.originalButtoncs9.Size = new System.Drawing.Size(167, 50);
            this.originalButtoncs9.Sizee = new System.Drawing.Size(136, 50);
            this.originalButtoncs9.TabIndex = 0;
            this.originalButtoncs9.txt = "Circular Ring";
            this.originalButtoncs9.ButtonClick += new Maa.ButtonClick(this.originalButtoncs9_ButtonClick);
            // 
            // originalButtoncs8
            // 
            this.originalButtoncs8.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs8.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs8.Location = new System.Drawing.Point(0, 439);
            this.originalButtoncs8.Name = "originalButtoncs8";
            this.originalButtoncs8.Size = new System.Drawing.Size(167, 57);
            this.originalButtoncs8.Sizee = new System.Drawing.Size(136, 57);
            this.originalButtoncs8.TabIndex = 0;
            this.originalButtoncs8.txt = "Rectangular Box";
            this.originalButtoncs8.ButtonClick += new Maa.ButtonClick(this.originalButtoncs8_ButtonClick);
            // 
            // originalButtoncs6
            // 
            this.originalButtoncs6.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs6.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs6.Location = new System.Drawing.Point(0, 314);
            this.originalButtoncs6.Name = "originalButtoncs6";
            this.originalButtoncs6.Size = new System.Drawing.Size(167, 57);
            this.originalButtoncs6.Sizee = new System.Drawing.Size(136, 57);
            this.originalButtoncs6.TabIndex = 0;
            this.originalButtoncs6.txt = "Circular Sector";
            this.originalButtoncs6.ButtonClick += new Maa.ButtonClick(this.originalButtoncs6_ButtonClick);
            // 
            // originalButtoncs5
            // 
            this.originalButtoncs5.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs5.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs5.Location = new System.Drawing.Point(0, 252);
            this.originalButtoncs5.Name = "originalButtoncs5";
            this.originalButtoncs5.Size = new System.Drawing.Size(167, 56);
            this.originalButtoncs5.Sizee = new System.Drawing.Size(136, 56);
            this.originalButtoncs5.TabIndex = 0;
            this.originalButtoncs5.txt = "Paralellogram";
            this.originalButtoncs5.ButtonClick += new Maa.ButtonClick(this.originalButtoncs5_ButtonClick);
            // 
            // originalButtoncs4
            // 
            this.originalButtoncs4.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs4.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs4.Location = new System.Drawing.Point(0, 188);
            this.originalButtoncs4.Name = "originalButtoncs4";
            this.originalButtoncs4.Size = new System.Drawing.Size(167, 58);
            this.originalButtoncs4.Sizee = new System.Drawing.Size(136, 58);
            this.originalButtoncs4.TabIndex = 0;
            this.originalButtoncs4.txt = "Triangle";
            this.originalButtoncs4.ButtonClick += new Maa.ButtonClick(this.originalButtoncs4_ButtonClick);
            // 
            // originalButtoncs3
            // 
            this.originalButtoncs3.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs3.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs3.Location = new System.Drawing.Point(0, 126);
            this.originalButtoncs3.Name = "originalButtoncs3";
            this.originalButtoncs3.Size = new System.Drawing.Size(167, 56);
            this.originalButtoncs3.Sizee = new System.Drawing.Size(136, 56);
            this.originalButtoncs3.TabIndex = 0;
            this.originalButtoncs3.txt = "Rectangle";
            this.originalButtoncs3.ButtonClick += new Maa.ButtonClick(this.originalButtoncs3_ButtonClick);
            // 
            // originalButtoncs2
            // 
            this.originalButtoncs2.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs2.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs2.Location = new System.Drawing.Point(0, 64);
            this.originalButtoncs2.Name = "originalButtoncs2";
            this.originalButtoncs2.Size = new System.Drawing.Size(167, 56);
            this.originalButtoncs2.Sizee = new System.Drawing.Size(136, 56);
            this.originalButtoncs2.TabIndex = 0;
            this.originalButtoncs2.txt = "Sqaure";
            this.originalButtoncs2.ButtonClick += new Maa.ButtonClick(this.originalButtoncs2_ButtonClick);
            // 
            // originalButtoncs1
            // 
            this.originalButtoncs1.Fontt = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs1.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs1.Location = new System.Drawing.Point(0, 2);
            this.originalButtoncs1.Name = "originalButtoncs1";
            this.originalButtoncs1.Size = new System.Drawing.Size(167, 56);
            this.originalButtoncs1.Sizee = new System.Drawing.Size(136, 56);
            this.originalButtoncs1.TabIndex = 0;
            this.originalButtoncs1.txt = "Circle";
            this.originalButtoncs1.ButtonClick += new Maa.ButtonClick(this.originalButtoncs1_ButtonClick);
            // 
            // Shapes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.originalButtoncs7);
            this.Controls.Add(this.History);
            this.Controls.Add(this.Done);
            this.Controls.Add(this.result);
            this.Controls.Add(this.output);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.originalButtoncs14);
            this.Controls.Add(this.originalButtoncs13);
            this.Controls.Add(this.originalButtoncs12);
            this.Controls.Add(this.originalButtoncs11);
            this.Controls.Add(this.originalButtoncs10);
            this.Controls.Add(this.originalButtoncs9);
            this.Controls.Add(this.originalButtoncs8);
            this.Controls.Add(this.originalButtoncs6);
            this.Controls.Add(this.originalButtoncs5);
            this.Controls.Add(this.originalButtoncs4);
            this.Controls.Add(this.originalButtoncs3);
            this.Controls.Add(this.originalButtoncs2);
            this.Controls.Add(this.originalButtoncs1);
            this.Name = "Shapes";
            this.Size = new System.Drawing.Size(1073, 578);
            this.Load += new System.EventHandler(this.Shapes_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private OriginalButtoncs originalButtoncs1;
        private OriginalButtoncs originalButtoncs2;
        private OriginalButtoncs originalButtoncs3;
        private OriginalButtoncs originalButtoncs4;
        private OriginalButtoncs originalButtoncs5;
        private OriginalButtoncs originalButtoncs6;
        private OriginalButtoncs originalButtoncs8;
        private OriginalButtoncs originalButtoncs9;
        private OriginalButtoncs originalButtoncs10;
        private OriginalButtoncs originalButtoncs11;
        private OriginalButtoncs originalButtoncs12;
        private OriginalButtoncs originalButtoncs13;
        private OriginalButtoncs originalButtoncs14;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label output;
        private System.Windows.Forms.Label result;
        private System.Windows.Forms.Button Done;
        private OriginalButtoncs originalButtoncs7;
        private System.Windows.Forms.ListBox History;
    }
}
