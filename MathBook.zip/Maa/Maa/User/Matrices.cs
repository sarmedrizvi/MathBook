﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maa
{
    public partial class Matricess : UserControl
    {
        public Matricess()
        {
            InitializeComponent();
        }
      static  int RowCount;
      static  int ColumnCount;
      static  TextBox[,] lbl;
        static TextBox[,] output = new TextBox[0,0];
        bool isSub = false, isAdd = false, isMulp = false, isDivide = false, isMultiplyMatrix = false,
            isAddMatrix = false, isSubMatrix = false, isFindX = false;

             


        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
           
            try
            {

                RowCount = Convert.ToInt32(textBox1.Text);
                ColumnCount = Convert.ToInt32(textBox2.Text);
                lbl = new TextBox[RowCount, ColumnCount];

                for (int i = 0; i < RowCount; i++)
                {
                    for (int j = 0; j <ColumnCount; j++)
                    {
                        panel1.BackColor = Color.Purple;
                        lbl[i, j] = new TextBox();
                        lbl[i, j].ForeColor = Color.Purple;
                        lbl[i, j].Font = new Font("Showcard Gothic", 35F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(0)));
                   
                        lbl[i, j].Size = new Size(65, 70);

                        lbl[i, j].Location = new Point(j * 75, i * 80);
                        lbl[i, j].BackColor = Color.White;
                        lbl[i, j].KeyDown += Matrices_KeyDown;
                        lbl[i, j].KeyPress += Matrices_KeyPress;
                        panel1.Controls.Add(lbl[i, j]);
                        originalButtoncs1.Enabled = false;
                        originalButtoncs10.Enabled = true;originalButtoncs11.Enabled = true;originalButtoncs12.Enabled = true;originalButtoncs13.Enabled = true;
                        originalButtoncs15.Enabled = true;
                        originalButtoncs17.Enabled = true;button2.Enabled = true;originalButtoncs4.Enabled = true;originalButtoncs5.Enabled = true;
                        originalButtoncs6.Enabled = true;
                        originalButtoncs7.Enabled = true;originalButtoncs8.Enabled = true;originalButtoncs9.Enabled = true;originalButtoncs14.Enabled = true;
                    }

                }
                int a = 75 * ColumnCount;
               
                if (a > 340) { a = 340; }
                int b = 80 * RowCount; ;
                if (b > 420) { b = 420; }
                
                panel1.Size = new Size(a, b);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            

        }

        private void Matrices_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }
        }

        private void Matrices_KeyPress(object sender, KeyPressEventArgs e)
        {
           
                  
         e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) &&  !char.IsPunctuation('+') ;
        
           
        }

       
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {
            originalButtoncs10.Enabled = false; originalButtoncs11.Enabled = false; originalButtoncs12.Enabled = false; originalButtoncs13.Enabled = false;
            originalButtoncs15.Enabled = false;
            originalButtoncs17.Enabled = false; button2.Enabled = false; originalButtoncs4.Enabled = false; originalButtoncs5.Enabled = false;
            originalButtoncs6.Enabled =false;
            originalButtoncs7.Enabled = false; originalButtoncs8.Enabled = false; originalButtoncs9.Enabled = false;originalButtoncs14.Enabled = false;

            originalButtoncs1.Enabled = true;
            panel1.BackColor = Color.Transparent;panel2.BackColor = Color.Transparent;
            textBox1.Text = "Row";textBox2.Text = "Column";
            for (int i = 0; i <RowCount; i++)
            {
                for (int j = 0; j <ColumnCount; j++)
                {
                    panel1.Controls.Remove(lbl[i, j]);
                }

            }
            for (int i = 0; i < input.GetLength(0); i++)
            {
                for (int j = 0; j < input.GetLength(1); j++)
                {
                    panel1.Controls.Remove(input[i, j]);
                }
            }
            

            EmptyOutput();textBox3.Text = "";textBox3.Enabled = false;label3.Text = "User Input";
            button1.Visible = false;textBox5.Visible = false;
        }
        public static double[,] Lbl(TextBox [,] lb)
        {
            double[,] a = new double[RowCount, ColumnCount];
            for (int i = 0; i < RowCount; i++)
            {
                for (int j = 0; j < ColumnCount; j++)
                {
                    a[i, j] = Convert.ToDouble(lbl[i, j].Text);
                }
            }
            return a;
        }

     
        private void originalButtoncs11_ButtonClick(object sender, EventArgs e)
        {
            try
            {
                Matrices c = new Matrices(Lbl(lbl));
                textBox4.Text = Matrices.Trace(c) + "";
                label4.Text = "Trace";
               
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
               
            }
           
        }

        private void originalButtoncs7_ButtonClick(object sender, EventArgs e)
        {
            try
            {
                textBox4.Text = Matrices.Determinent(Lbl(lbl).GetLength(0), Lbl(lbl)) + "";
                label4.Text = "Determinent";
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
               
            }

        }
        public void OutputMatrix(Matrices Matrix)
        {
            output = new TextBox[Matrix.Row, Matrix.Column];


            for (int i = 0; i < Matrix.Row; i++)
            {
                for (int j = 0; j < Matrix.Column; j++)
                {
                    panel2.BackColor = Color.Purple;
                    output[i, j] = new TextBox();
                    output[i, j].ForeColor = Color.Purple;
                    output[i, j].Font = new Font("Showcard Gothic", 35F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(0)));
                
                    output[i, j].Size = new Size(65, 70);
                    output[i, j].KeyPress += Matricess_KeyPress1;
                    output[i, j].Location = new Point(j * 75, i * 80);
                    output[i, j].BackColor = Color.White;

                    panel2.Controls.Add(output[i, j]);
                }
            }
            int b = 80 * output.GetLength(0); ;
            if (b > 420) { b = 420; }
            int a = 75 * output.GetLength(1);
            if (a > 340) { a = 340; }

            panel2.Size = new Size(a, b);
            
        }

        private void Matricess_KeyPress1(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;

        }

        TextBox[,] input = new TextBox[0, 0];
        public void InputMatrix()
        {
            
            try
            {
                int MatrixRow = Convert.ToInt32(textBox3.Text);
                int MatrixColumn = Convert.ToInt32(textBox5.Text);
                input = new TextBox[MatrixRow, MatrixColumn];
                for (int i = 0; i < MatrixRow; i++)
                {
                    for (int j = 0; j < MatrixColumn; j++)
                    {
                        panel1.BackColor = Color.Purple;
                        input[i, j] = new TextBox();
                        input[i, j].ForeColor = Color.Purple;
                        input[i, j].Font = new Font("Showcard Gothic", 35F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(0)));
                   
                        input[i, j].Size = new Size(65, 70);
                        input[i, j].KeyPress += Matricess_KeyPress;
                        input[i, j].Location = new Point(j * 75, i * 80);
                        input[i, j].BackColor = Color.White;
                        input[i, j].KeyDown += Matricess_KeyDown;

                        panel1.Controls.Add(input[i, j]);
                    }
                }


                int a = 75 * input.GetLength(1);
                if (a > 340) { a = 340; }
                int b = 80 * input.GetLength(0); 
                if (b > 420) { b = 420; }

                panel1.Size = new Size(a, b);
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void Matricess_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }
        }

        private void Matricess_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsPunctuation(e.KeyChar);
        }

        public static TextBox[,] MatrixToTextBox(Matrices Matrix)
        {
            
            for (int i = 0; i < Matrix.Row; i++)
            {
                for (int j = 0; j < Matrix.Column; j++)
                {
                    output[i, j].Text = Convert.ToString(Matrix.Elements[i, j]).ToString();
                }
            }
            return output;
        }

        private void originalButtoncs9_ButtonClick(object sender, EventArgs e)
        {
            EmptyOutput();
            try
            {
                Matrices m;
                m = Matrices.Adjoint(Lbl(lbl));
                OutputMatrix(m);
                MatrixToTextBox(m);
                label2.Text = "Adjoint";
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        public void EmptyOutput()
        {

            for (int i = 0; i < output.GetLength(0); i++)
            {
                for (int j = 0; j < output.GetLength(1); j++)
                {
                    panel2.Controls.Remove(output[i, j]);

                }
            }
            panel2.BackColor = Color.Transparent;
        }

        private void originalButtoncs15_ButtonClick(object sender, EventArgs e)
        {
            try
            {
                textBox3.Text = "";
                textBox3.Enabled = true;
                label3.Text = "Multiply with Number";
                isMulp = true;

                isSub = false;
                isAdd = false; isDivide = false;
                isSubMatrix = false;
                isAddMatrix = false; isMultiplyMatrix = false; isFindX = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsPunctuation(e.KeyChar);
        }

        private void originalButtoncs6_ButtonClick(object sender, EventArgs e)
        {
            textBox3.Text = "";
            textBox3.Enabled = true;
            label3.Text = "Add with Number";
            isSub = false;
            isAdd = true; isDivide = false; isMulp = false;
            isSubMatrix = false;
            isAddMatrix = false; isMultiplyMatrix = false; isFindX = false;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < RowCount; i++)
            {
                for (int j = 0; j < ColumnCount; j++)
                {
                    panel1.Controls.Remove(lbl[i, j]);
                }

            }
            for (int i = 0; i < input.GetLength(0); i++)
            {
                for (int j = 0; j < input.GetLength(1); j++)
                {
                    panel1.Controls.Remove(input[i, j]);
                }
            }
            InputMatrix();
            button1.Visible = false;textBox5.Visible = false;textBox3.Text = "";label3.Text = "User Input";
           
        }

        private void originalButtoncs4_ButtonClick(object sender, EventArgs e)
        {
            button1.Visible = true;
            outMatrice = new Matrices(Lbl(lbl)); textBox5.Visible = true; textBox3.Enabled = true;
            textBox3.Text = "Row"; textBox5.Text = "Column";
            label3.Text = " Subtract with Matrix";
            isSubMatrix = true;
            isAddMatrix = false; isMultiplyMatrix = false; isFindX = false;
            isAdd = false; isDivide = false; isMulp = false; isSub = false;

        }

        private void originalButtoncs5_ButtonClick(object sender, EventArgs e)
        {
            
            outMatrice = new Matrices(Lbl(lbl));
            textBox5.Visible = true; textBox3.Enabled = true;
            textBox3.Text = "Row"; textBox5.Text = "Column";
            label3.Text = " Multiply with Matrix";
            isMultiplyMatrix = true; isSubMatrix = false; isSub = false;
            isAdd = false; isDivide = false; isMulp = false; isAddMatrix = false;
            button1.Visible = true;isFindX = false;

        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {
                if (isSub == true)
            {
                EmptyOutput();
                Matrices m = new Matrices(Lbl(lbl));
                Matrices matrices = m - Convert.ToDouble(textBox3.Text);
                OutputMatrix(matrices);
                MatrixToTextBox(matrices);
                isSub = false;
                textBox3.Enabled = false;

            }
            else if (isMulp == true)
            {

                EmptyOutput();
                Matrices m = new Matrices(Lbl(lbl));
                Matrices matrices = m * Convert.ToDouble(textBox3.Text);
                OutputMatrix(matrices);
                MatrixToTextBox(matrices);
                isMulp = false;
                textBox3.Enabled = false;

            }
            else if (isAdd == true)
            {
                EmptyOutput();
                Matrices m = new Matrices(Lbl(lbl));
                Matrices matrices = m + Convert.ToDouble(textBox3.Text);
                OutputMatrix(matrices);
                MatrixToTextBox(matrices);
                isAdd = false;
                textBox3.Enabled = false;
            }
            else if (isDivide == true)
            {
                EmptyOutput();
                Matrices m = new Matrices(Lbl(lbl));
                Matrices matrices = m / Convert.ToDouble(textBox3.Text);
                OutputMatrix(matrices);
                MatrixToTextBox(matrices);
                isDivide = false;
                textBox3.Enabled = false;
            }
            else if (isAddMatrix == true)
            {
                double[,] a = new double[input.GetLength(0), input.GetLength(1)];
                EmptyOutput();
                for (int i = 0; i < input.GetLength(0); i++)
                {
                    for (int j = 0; j < input.GetLength(1); j++)
                    {
                        a[i, j] = Convert.ToDouble(input[i, j].Text);
                    }
                }
                Matrices m1 = new Matrices(a);
                Matrices m2 = outMatrice + m1;
                OutputMatrix(m2);
                MatrixToTextBox(m2);
                isAddMatrix = false;


            }
            else if (isSubMatrix == true)
            {
                double[,] a = new double[input.GetLength(0), input.GetLength(1)];
                EmptyOutput();
                for (int i = 0; i < input.GetLength(0); i++)
                {
                    for (int j = 0; j < input.GetLength(1); j++)
                    {
                        a[i, j] = Convert.ToDouble(input[i, j].Text);
                    }
                }
                Matrices m1 = new Matrices(a);
                Matrices m2 = outMatrice - m1;
                OutputMatrix(m2);
                MatrixToTextBox(m2);
                isSubMatrix = false;
            }
            else if (isMultiplyMatrix == true)
            {
                double[,] a = new double[input.GetLength(0), input.GetLength(1)];
                EmptyOutput();
                for (int i = 0; i < input.GetLength(0); i++)
                {
                    for (int j = 0; j < input.GetLength(1); j++)
                    {
                        a[i, j] = Convert.ToDouble(input[i, j].Text);
                    }
                }
                Matrices m1 = new Matrices(a);
                Matrices m2 = outMatrice * m1;
                OutputMatrix(m2);
                MatrixToTextBox(m2);
                isMultiplyMatrix = false;
            }
            else if (isFindX == true)
            {
                double[,] a = new double[input.GetLength(0), input.GetLength(1)];
                EmptyOutput();
                for (int i = 0; i < input.GetLength(0); i++)
                {
                    for (int j = 0; j < input.GetLength(1); j++)
                    {
                        a[i, j] = Convert.ToDouble(input[i, j].Text);
                    }
                }
                Matrices m1 = new Matrices(a);
                string m2 = Matrices.SolveMatrix(outMatrice, m1);
                textBox4.Text = m2;

                isFindX = false;
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Matricess_Load(object sender, EventArgs e)
        {

        }

        private void originalButtoncs12_ButtonClick(object sender, EventArgs e)
        {
            outMatrice = new Matrices(Lbl(lbl));
            textBox5.Visible = true; textBox3.Enabled = true;
            textBox3.Text = "Row"; textBox5.Text = "Column";
            label3.Text = " Find Unknown";
            isMultiplyMatrix = false; isSubMatrix = false; isSub = false;
            isAdd = false; isDivide = false; isMulp = false; isAddMatrix = false;
            button1.Visible = true;isFindX = true;
        }

        private void originalButtoncs17_ButtonClick(object sender, EventArgs e)
        {
            textBox3.Text = "";
            textBox3.Enabled = true;
            label3.Text = "Divide with Number";
            isSub = false;
            isAdd = false; isDivide = true; isMulp = false;
            isSubMatrix = false;
            isAddMatrix = false; isMultiplyMatrix = false; isFindX = false;
        }
        Matrices outMatrice = new Matrices();
        private void originalButtoncs14_ButtonClick(object sender, EventArgs e)
        {
           
            outMatrice = new Matrices(Lbl(lbl));textBox5.Visible = true;textBox3.Enabled = true;
            textBox3.Text = "Row";textBox5.Text = "Column";
            label3.Text = " Add with Matrix";
            isAddMatrix = true;
            button1.Visible = true;
            isSubMatrix = false; isSub = false;
            isAdd = false; isDivide = false; isMulp = false;isMultiplyMatrix = false;isFindX = false;


        }

        private void originalButtoncs10_ButtonClick(object sender, EventArgs e)
        {
            EmptyOutput();
            try
            {
                Matrices m1 = new Matrices(Lbl(lbl));
                Matrices m = Matrices.Inverse(m1);
                OutputMatrix(m);
                MatrixToTextBox(m);
                label2.Text = "Inverse";
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            


        }

        private void originalButtoncs13_ButtonClick(object sender, EventArgs e)
        { Matrices m = new Matrices(Lbl(lbl));
           textBox4.Text= Matrices.TypeOfMatrix(m);
            label4.Text = "Type Of Matrix";
        }

        private void originalButtoncs8_ButtonClick(object sender, EventArgs e)
        {
            textBox3.Text = "";
            textBox3.Enabled = true;
            label3.Text = "Subtract with";
            isSub = true;
            isAdd = false;isDivide = false;isMulp = false;
            isSubMatrix = false;
            isAddMatrix = false; isMultiplyMatrix = false; isFindX = false;


        }
    }
}

