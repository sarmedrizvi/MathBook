﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;

namespace Maa
{
    public partial class WorkBook : UserControl
    {
        public WorkBook()
        {
            InitializeComponent();
        }

        private void originalButtoncs1_Load(object sender, EventArgs e)
        {
           

        }

        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var xdoc = XDocument.Load(openFileDialog1.FileName);
                var employeeCount = (double)xdoc.XPathEvaluate("count(//Expression)");
                XmlReader x = XmlReader.Create(openFileDialog1.FileName);
                for (int i = 0; i < employeeCount; i++)
                {
                    ToolTip t = new ToolTip();
                    Label a=new Label(), b=new Label(), c=new Label(), d=new Label();
                    a.Dock = DockStyle.Top;
                    a.AutoSize = false;
                    a.TextAlign = ContentAlignment.TopCenter;
                    a.Font = new Font("Cambria", 10f, FontStyle.Bold, GraphicsUnit.Point);
                    a.ForeColor = Color.DarkSlateGray;a.Cursor = Cursors.IBeam;
                    panel1.Controls.Add(a);
                    b.Dock = DockStyle.Top;
                    b.AutoSize = false;
                    b.TextAlign = ContentAlignment.TopCenter;
                    b.Font = new Font("Cambria", 10f, FontStyle.Bold, GraphicsUnit.Point);
                    b.ForeColor = Color.DarkSlateGray; b.Cursor = Cursors.IBeam;
                    panel2.Controls.Add(b);
                    c.Dock = DockStyle.Top;
                    c.AutoSize = false;
                    c.TextAlign = ContentAlignment.TopCenter;
                    c.Font = new Font("Cambria", 10f, FontStyle.Bold, GraphicsUnit.Point);
                    c.ForeColor = Color.DarkSlateGray; c.Cursor = Cursors.IBeam;
                    panel3.Controls.Add(c);
                    d.Dock = DockStyle.Top;
                    d.AutoSize = false;
                    d.TextAlign = ContentAlignment.TopCenter;
                    d.Font = new Font("Cambria", 10f, FontStyle.Bold, GraphicsUnit.Point);
                    d.ForeColor = Color.DarkSlateGray; d.Cursor = Cursors.IBeam;
                    panel7.Controls.Add(d);
                    x.ReadToFollowing("Expression");
                    x.MoveToFirstAttribute();
                    a.Text = x.Value;
                    
                    x.MoveToNextAttribute();
                    b.Text = x.Value;
                    x.MoveToNextAttribute();
                    c.Text = x.Value;
                    x.MoveToNextAttribute();
                    d.Text = x.Value;
                    t.SetToolTip(a, a.Text);
                    t.SetToolTip(b, b.Text);
                    t.SetToolTip(c, c.Text);
                    t.SetToolTip(d, d.Text);
               
                }
              

            }
        }

        private void WorkBook_Load(object sender, EventArgs e)
        {

        }
    }
}
