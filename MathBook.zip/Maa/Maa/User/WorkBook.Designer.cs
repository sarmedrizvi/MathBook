﻿namespace Maa
{
    partial class WorkBook
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.value1Panel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.object1 = new System.Windows.Forms.Label();
            this.OpPanel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.operation = new System.Windows.Forms.Label();
            this.value2Panel = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.object2 = new System.Windows.Forms.Label();
            this.resultsPanel = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.result = new System.Windows.Forms.Label();
            this.originalButtoncs1 = new Maa.OriginalButtoncs();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.value1Panel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.OpPanel.SuspendLayout();
            this.panel5.SuspendLayout();
            this.value2Panel.SuspendLayout();
            this.panel6.SuspendLayout();
            this.resultsPanel.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // value1Panel
            // 
            this.value1Panel.Controls.Add(this.panel1);
            this.value1Panel.Controls.Add(this.panel4);
            this.value1Panel.Dock = System.Windows.Forms.DockStyle.Left;
            this.value1Panel.Location = new System.Drawing.Point(0, 0);
            this.value1Panel.Name = "value1Panel";
            this.value1Panel.Size = new System.Drawing.Size(288, 587);
            this.value1Panel.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 37);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(288, 550);
            this.panel1.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panel4.Controls.Add(this.object1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(288, 37);
            this.panel4.TabIndex = 0;
            // 
            // object1
            // 
            this.object1.AutoSize = true;
            this.object1.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.object1.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.object1.Location = new System.Drawing.Point(110, 10);
            this.object1.Name = "object1";
            this.object1.Size = new System.Drawing.Size(52, 19);
            this.object1.TabIndex = 0;
            this.object1.Text = "Object";
            // 
            // OpPanel
            // 
            this.OpPanel.Controls.Add(this.panel2);
            this.OpPanel.Controls.Add(this.panel5);
            this.OpPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.OpPanel.Location = new System.Drawing.Point(288, 0);
            this.OpPanel.Name = "OpPanel";
            this.OpPanel.Size = new System.Drawing.Size(113, 587);
            this.OpPanel.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 37);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(113, 550);
            this.panel2.TabIndex = 2;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panel5.Controls.Add(this.operation);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(113, 37);
            this.panel5.TabIndex = 1;
            // 
            // operation
            // 
            this.operation.AutoSize = true;
            this.operation.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.operation.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.operation.Location = new System.Drawing.Point(6, 10);
            this.operation.Name = "operation";
            this.operation.Size = new System.Drawing.Size(72, 19);
            this.operation.TabIndex = 0;
            this.operation.Text = "Operation";
            // 
            // value2Panel
            // 
            this.value2Panel.Controls.Add(this.panel3);
            this.value2Panel.Controls.Add(this.panel6);
            this.value2Panel.Dock = System.Windows.Forms.DockStyle.Left;
            this.value2Panel.Location = new System.Drawing.Point(401, 0);
            this.value2Panel.Name = "value2Panel";
            this.value2Panel.Size = new System.Drawing.Size(276, 587);
            this.value2Panel.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 37);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(276, 550);
            this.panel3.TabIndex = 2;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panel6.Controls.Add(this.object2);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(276, 37);
            this.panel6.TabIndex = 1;
            // 
            // object2
            // 
            this.object2.AutoSize = true;
            this.object2.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.object2.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.object2.Location = new System.Drawing.Point(110, 8);
            this.object2.Name = "object2";
            this.object2.Size = new System.Drawing.Size(52, 19);
            this.object2.TabIndex = 0;
            this.object2.Text = "Object";
            // 
            // resultsPanel
            // 
            this.resultsPanel.Controls.Add(this.panel7);
            this.resultsPanel.Controls.Add(this.panel8);
            this.resultsPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.resultsPanel.Location = new System.Drawing.Point(677, 0);
            this.resultsPanel.Name = "resultsPanel";
            this.resultsPanel.Size = new System.Drawing.Size(298, 587);
            this.resultsPanel.TabIndex = 3;
            // 
            // panel7
            // 
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 37);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(298, 550);
            this.panel7.TabIndex = 2;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panel8.Controls.Add(this.result);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(298, 37);
            this.panel8.TabIndex = 1;
            // 
            // result
            // 
            this.result.AutoSize = true;
            this.result.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.result.Location = new System.Drawing.Point(110, 8);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(50, 19);
            this.result.TabIndex = 0;
            this.result.Text = "Result";
            // 
            // originalButtoncs1
            // 
            this.originalButtoncs1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.originalButtoncs1.Fontt = new System.Drawing.Font("Bell MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs1.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.originalButtoncs1.Location = new System.Drawing.Point(981, 295);
            this.originalButtoncs1.Name = "originalButtoncs1";
            this.originalButtoncs1.Size = new System.Drawing.Size(141, 54);
            this.originalButtoncs1.Sizee = new System.Drawing.Size(110, 54);
            this.originalButtoncs1.TabIndex = 4;
            this.originalButtoncs1.txt = "Open Work";
            this.originalButtoncs1.ButtonClick += new Maa.ButtonClick(this.originalButtoncs1_ButtonClick);
            this.originalButtoncs1.Load += new System.EventHandler(this.originalButtoncs1_Load);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // WorkBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.originalButtoncs1);
            this.Controls.Add(this.resultsPanel);
            this.Controls.Add(this.value2Panel);
            this.Controls.Add(this.OpPanel);
            this.Controls.Add(this.value1Panel);
            this.Name = "WorkBook";
            this.Size = new System.Drawing.Size(1125, 587);
            this.Load += new System.EventHandler(this.WorkBook_Load);
            this.value1Panel.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.OpPanel.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.value2Panel.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.resultsPanel.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel value1Panel;
        private System.Windows.Forms.Panel OpPanel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label operation;
        private System.Windows.Forms.Panel value2Panel;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label object2;
        private System.Windows.Forms.Panel resultsPanel;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label result;
        private OriginalButtoncs originalButtoncs1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label object1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel7;
    }
}
