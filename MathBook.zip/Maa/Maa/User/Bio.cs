﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Maa
{
    public partial class Bio : UserControl
    {
        public Bio()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            originalButtoncs1.Enabled = false;
            originalButtoncs2.Enabled = false;
            originalButtoncs3.Enabled = false;
            originalButtoncs4.Enabled = false;
            originalButtoncs5.Enabled = false;
            originalButtoncs6.Enabled = false;
            originalButtoncs7.Enabled = false;
            originalButtoncs8.Enabled = false;
            originalButtoncs9.Enabled = false;
            originalButtoncs10.Enabled = false;
            label3.Text = "";
            textBox1.Text="Number Of Terms(n)";
            textBox2.Text = "Required Term(r)";
            richTextBox1.Text = "Expression";
           
        }

        private void originalButtoncs10_ButtonClick(object sender, EventArgs e)
        {try
            {
                label3.Text = Binomial.factorial(Convert.ToInt32(textBox1.Text)).ToString();
                History.Items.Add(textBox1.Text + "! =" + label3.Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

      

        private void originalButtoncs9_ButtonClick(object sender, EventArgs e)
        {try
            {
                label3.Text = Binomial.nCr(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text)).ToString();
                History.Items.Add(textBox1.Text + $"C{textBox2.Text} =" + label3.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void originalButtoncs4_ButtonClick(object sender, EventArgs e)
        {try
            { label3.Text = Binomial.nPr(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text)).ToString();
                History.Items.Add(textBox1.Text + $"P{textBox2.Text} =" + label3.Text);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {try
            {
                Expression expression = new Expression(richTextBox1.Text);
                label3.Text = Binomial.RequiredTerm(expression, Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text)).ToString();
                History.Items.Add(expression + $",n is {textBox1.Text} & r is {textBox2.Text},Reqterm=" + label3.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void originalButtoncs7_ButtonClick(object sender, EventArgs e)
        {
           label3.Text= Binomial.BinonialExpansion(new Expression(richTextBox1.Text), Convert.ToInt32(textBox1.Text)).ToString();
            History.Items.Add(richTextBox1.Text + $",n is {textBox1.Text},Expansion=" + label3.Text);
        }

        private void originalButtoncs8_ButtonClick(object sender, EventArgs e)
        {
           label3.Text= Binomial.MiddleTerm(new Expression(richTextBox1.Text), Convert.ToInt32(textBox1.Text)).ToString();
            History.Items.Add(richTextBox1.Text + $",n is {textBox1.Text},Midterm=" + label3.Text);
        }

        private void originalButtoncs3_ButtonClick(object sender, EventArgs e)
        {
           label3.Text= Binomial.TermIndependedOfX(new Expression(richTextBox1.Text), Convert.ToInt32(textBox1.Text)).ToString();
            History.Items.Add(richTextBox1.Text + $",n is {textBox1.Text},TermindepOfx=" + label3.Text);
        }

        private void originalButtoncs5_ButtonClick(object sender, EventArgs e)
        {
           label3.Text= Binomial.SumOfCoefficient(new Expression(richTextBox1.Text), Convert.ToInt32(textBox1.Text)).ToString();
            History.Items.Add(richTextBox1.Text + $",n is {textBox1.Text},Sum=" + label3.Text);
        }

        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {
            label3.Text = Binomial.SumOfEvenCoefficient(new Expression(richTextBox1.Text), Convert.ToInt32(textBox1.Text)).ToString();
            History.Items.Add(richTextBox1.Text + $",n is {textBox1.Text},SumOfEven=" + label3.Text);
        }

        private void originalButtoncs6_ButtonClick(object sender, EventArgs e)
        {
            label3.Text = Binomial.SumOfOddCoefficient(new Expression(richTextBox1.Text), Convert.ToInt32(textBox1.Text)).ToString();
            History.Items.Add(richTextBox1.Text + $",n is {textBox1.Text},SumOfOdd=" + label3.Text);
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar); ;
        }

        private void richTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'x' || e.KeyChar == '.' || e.KeyChar == '+' || e.KeyChar == '-' || e.KeyChar == '*' || e.KeyChar == '^')
            {

            }
            else
            {
                e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar); ;
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {if (richTextBox1.Text != "")
            {
                originalButtoncs1.Enabled = true;
                originalButtoncs2.Enabled = true;
                originalButtoncs3.Enabled = true;
                originalButtoncs4.Enabled = true;
                originalButtoncs5.Enabled = true;
                originalButtoncs6.Enabled = true;
                originalButtoncs7.Enabled = true;
                originalButtoncs8.Enabled = true;
                originalButtoncs9.Enabled = true;
                originalButtoncs10.Enabled = true;
            }
        else
            {
                originalButtoncs1.Enabled = false;
                originalButtoncs2.Enabled = false;
                originalButtoncs3.Enabled = false;
                originalButtoncs4.Enabled = false;
                originalButtoncs5.Enabled = false;
                originalButtoncs6.Enabled = false;
                originalButtoncs7.Enabled = false;
                originalButtoncs8.Enabled = false;
                originalButtoncs9.Enabled = false;
                originalButtoncs10.Enabled = false;
            }

        }


        private void originalButtoncs11_ButtonClick(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFile=new SaveFileDialog())
            {
                saveFile.Filter = "M|*.Math|Text|*.txt";
                if (saveFile.ShowDialog()==DialogResult.OK)
                {
                    XmlWriter xmlWriter = XmlWriter.Create(saveFile.FileName);
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("Expressions");
                    for (int i = 0; i < History.Items.Count; i++)
                    {
                      
                        string[] s = History.Items[i].ToString().Split('=');
                        if (s[0].Contains("P"))
                        {
                            string[] v = s[0].Split(new string[] { "P" }, StringSplitOptions.None);
                            xmlWriter.WriteStartElement("Expression");
                            xmlWriter.WriteAttributeString("userexpression1",v[0]);
                            xmlWriter.WriteAttributeString("operation","nPr");
                            xmlWriter.WriteAttributeString("userexpression2",v[1]);
                           
                            xmlWriter.WriteAttributeString("Result", s[1]);
                            xmlWriter.WriteEndElement();
                        }
                        else if(s[0].Contains("C"))
                        {
                            string[] v = s[0].Split(new string[] { "C" }, StringSplitOptions.None);
                            xmlWriter.WriteStartElement("Expression");
                            xmlWriter.WriteAttributeString("userexpression1", v[0]);
                            xmlWriter.WriteAttributeString("operation", "nCr");
                            xmlWriter.WriteAttributeString("userexpression2", v[1]);
                           
                            xmlWriter.WriteAttributeString("Result", s[1]);
                            xmlWriter.WriteEndElement();

                        }
                        else if(s[0].Contains("!"))
                        {
                            string[] v = s[0].Split(new string[] { "!" }, StringSplitOptions.None);
                            xmlWriter.WriteStartElement("Expression");
                            xmlWriter.WriteAttributeString("userexpression1", v[0]);
                            xmlWriter.WriteAttributeString("operation", "Factorial");
                            xmlWriter.WriteAttributeString("userexpression2", " ");
                          
                            xmlWriter.WriteAttributeString("Result", s[1]);
                            xmlWriter.WriteEndElement();
                        }
                        else
                        {
                            string[] v = s[0].Split(',');
                            xmlWriter.WriteStartElement("Expression");
                            xmlWriter.WriteAttributeString("userexpression1", v[0]);
                            xmlWriter.WriteAttributeString("operation", v[2]);
                            xmlWriter.WriteAttributeString("userexpression2", v[1]);
                            
                            xmlWriter.WriteAttributeString("Result", s[1]);
                            xmlWriter.WriteEndElement();
                        }
                    }
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndDocument();
                    xmlWriter.Close();
                }
            }
        }

        private void History_SelectedValueChanged(object sender, EventArgs e)
        {

            ToolTip t = new ToolTip();
            t.SetToolTip(History, History.SelectedItem.ToString());
        }
    }
}
