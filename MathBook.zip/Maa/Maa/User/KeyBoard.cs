﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maa
{
    public delegate void click(object sender, EventArgs e);
    public partial class KeyBoard : UserControl
    {
        public event click zero; public event click one; public event click two; public event click three; public event click four; public event click five;
        public event click six; public event click seven; public event click eight; public event click nine; public event click plus; public event click minus;
        public event click multiply; public event click divide; public event click deci; public event click power; public event click X;
        public KeyBoard()
        {
            InitializeComponent();
        }

        private void KeyBoard_Load(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (divide != null)
                divide(sender, e);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (zero != null)
                zero(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (one != null)
                one(sender, e);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (two != null)
                two(sender, e);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (three != null)
                three(sender, e);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (four != null)
                four(sender, e);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (five != null)
                five(sender, e);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (six != null)
                six(sender, e);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (seven != null)
                seven(sender, e);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (eight != null)
               eight(sender, e);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (nine != null)
                nine(sender, e);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (X != null)
                X(sender, e);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (plus != null)
                plus(sender, e);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (minus != null)
                minus(sender, e);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (multiply != null)
                multiply(sender, e);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (power != null)
                power(sender, e);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (deci != null)
                deci(sender, e);
        }
    }
}
