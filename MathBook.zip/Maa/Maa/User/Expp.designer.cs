﻿namespace Maa
{
    partial class Expp
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originalButtoncs9 = new Maa.OriginalButtoncs();
            this.originalButtoncs8 = new Maa.OriginalButtoncs();
            this.originalButtoncs11 = new Maa.OriginalButtoncs();
            this.originalButtoncs4 = new Maa.OriginalButtoncs();
            this.originalButtoncs10 = new Maa.OriginalButtoncs();
            this.originalButtoncs3 = new Maa.OriginalButtoncs();
            this.originalButtoncs5 = new Maa.OriginalButtoncs();
            this.originalButtoncs2 = new Maa.OriginalButtoncs();
            this.originalButtoncs1 = new Maa.OriginalButtoncs();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.Label();
            this.originalButtoncs6 = new Maa.OriginalButtoncs();
            this.History = new System.Windows.Forms.ListBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.originalButtoncs7 = new Maa.OriginalButtoncs();
            this.SuspendLayout();
            // 
            // originalButtoncs9
            // 
            this.originalButtoncs9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs9.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs9.Enabled = false;
            this.originalButtoncs9.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs9.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs9.Location = new System.Drawing.Point(405, 145);
            this.originalButtoncs9.Name = "originalButtoncs9";
            this.originalButtoncs9.Size = new System.Drawing.Size(173, 56);
            this.originalButtoncs9.Sizee = new System.Drawing.Size(105, 22);
            this.originalButtoncs9.TabIndex = 3;
            this.originalButtoncs9.txt = "Differentiate";
            this.originalButtoncs9.ButtonClick += new Maa.ButtonClick(this.originalButtoncs9_ButtonClick);
            // 
            // originalButtoncs8
            // 
            this.originalButtoncs8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs8.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs8.Enabled = false;
            this.originalButtoncs8.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs8.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs8.Location = new System.Drawing.Point(403, 401);
            this.originalButtoncs8.Name = "originalButtoncs8";
            this.originalButtoncs8.Size = new System.Drawing.Size(175, 56);
            this.originalButtoncs8.Sizee = new System.Drawing.Size(132, 22);
            this.originalButtoncs8.TabIndex = 3;
            this.originalButtoncs8.txt = "Solve Quadratic";
            this.originalButtoncs8.ButtonClick += new Maa.ButtonClick(this.originalButtoncs8_ButtonClick);
            // 
            // originalButtoncs11
            // 
            this.originalButtoncs11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs11.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs11.Enabled = false;
            this.originalButtoncs11.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs11.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs11.Location = new System.Drawing.Point(403, 277);
            this.originalButtoncs11.Name = "originalButtoncs11";
            this.originalButtoncs11.Size = new System.Drawing.Size(175, 56);
            this.originalButtoncs11.Sizee = new System.Drawing.Size(76, 22);
            this.originalButtoncs11.TabIndex = 3;
            this.originalButtoncs11.txt = "Evaluate";
            this.originalButtoncs11.ButtonClick += new Maa.ButtonClick(this.originalButtoncs11_ButtonClick);
            // 
            // originalButtoncs4
            // 
            this.originalButtoncs4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs4.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs4.Enabled = false;
            this.originalButtoncs4.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs4.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs4.Location = new System.Drawing.Point(600, 277);
            this.originalButtoncs4.Name = "originalButtoncs4";
            this.originalButtoncs4.Size = new System.Drawing.Size(173, 56);
            this.originalButtoncs4.Sizee = new System.Drawing.Size(117, 22);
            this.originalButtoncs4.TabIndex = 3;
            this.originalButtoncs4.txt = "Whole Power";
            this.originalButtoncs4.ButtonClick += new Maa.ButtonClick(this.originalButtoncs4_ButtonClick_1);
            // 
            // originalButtoncs10
            // 
            this.originalButtoncs10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs10.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs10.Enabled = false;
            this.originalButtoncs10.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs10.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs10.Location = new System.Drawing.Point(600, 207);
            this.originalButtoncs10.Name = "originalButtoncs10";
            this.originalButtoncs10.Size = new System.Drawing.Size(173, 56);
            this.originalButtoncs10.Sizee = new System.Drawing.Size(60, 22);
            this.originalButtoncs10.TabIndex = 3;
            this.originalButtoncs10.txt = "Graph";
            this.originalButtoncs10.ButtonClick += new Maa.ButtonClick(this.originalButtoncs10_ButtonClick);
            // 
            // originalButtoncs3
            // 
            this.originalButtoncs3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs3.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs3.Enabled = false;
            this.originalButtoncs3.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs3.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs3.Location = new System.Drawing.Point(403, 207);
            this.originalButtoncs3.Name = "originalButtoncs3";
            this.originalButtoncs3.Size = new System.Drawing.Size(175, 56);
            this.originalButtoncs3.Sizee = new System.Drawing.Size(166, 22);
            this.originalButtoncs3.TabIndex = 3;
            this.originalButtoncs3.txt = "Multiply Expression";
            this.originalButtoncs3.ButtonClick += new Maa.ButtonClick(this.originalButtoncs3_ButtonClick);
            // 
            // originalButtoncs5
            // 
            this.originalButtoncs5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs5.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs5.Enabled = false;
            this.originalButtoncs5.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs5.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs5.Location = new System.Drawing.Point(600, 401);
            this.originalButtoncs5.Name = "originalButtoncs5";
            this.originalButtoncs5.Size = new System.Drawing.Size(173, 56);
            this.originalButtoncs5.Sizee = new System.Drawing.Size(157, 22);
            this.originalButtoncs5.TabIndex = 3;
            this.originalButtoncs5.txt = "Divide Expressions";
            this.originalButtoncs5.ButtonClick += new Maa.ButtonClick(this.originalButtoncs5_ButtonClick);
            this.originalButtoncs5.Load += new System.EventHandler(this.originalButtoncs5_Load);
            // 
            // originalButtoncs2
            // 
            this.originalButtoncs2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs2.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs2.Enabled = false;
            this.originalButtoncs2.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs2.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs2.Location = new System.Drawing.Point(600, 339);
            this.originalButtoncs2.Name = "originalButtoncs2";
            this.originalButtoncs2.Size = new System.Drawing.Size(173, 56);
            this.originalButtoncs2.Sizee = new System.Drawing.Size(166, 22);
            this.originalButtoncs2.TabIndex = 3;
            this.originalButtoncs2.txt = "Subtract Expression";
            this.originalButtoncs2.ButtonClick += new Maa.ButtonClick(this.originalButtoncs2_ButtonClick);
            // 
            // originalButtoncs1
            // 
            this.originalButtoncs1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs1.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs1.Enabled = false;
            this.originalButtoncs1.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs1.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs1.Location = new System.Drawing.Point(403, 339);
            this.originalButtoncs1.Name = "originalButtoncs1";
            this.originalButtoncs1.Size = new System.Drawing.Size(175, 56);
            this.originalButtoncs1.Sizee = new System.Drawing.Size(131, 22);
            this.originalButtoncs1.TabIndex = 3;
            this.originalButtoncs1.txt = "Add Expression";
            this.originalButtoncs1.ButtonClick += new Maa.ButtonClick(this.originalButtoncs1_ButtonClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Bell MT", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(95, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(175, 56);
            this.label2.TabIndex = 1;
            this.label2.Text = "Output";
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Bell MT", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(530, 466);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 33);
            this.button1.TabIndex = 5;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Agency FB", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(403, 85);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(335, 36);
            this.textBox1.TabIndex = 4;
            this.textBox1.Text = "User Input";
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.richTextBox1.BackColor = System.Drawing.Color.White;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox1.Font = new System.Drawing.Font("Agency FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(403, 51);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(335, 35);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            this.richTextBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.richTextBox1_KeyDown);
            this.richTextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.richTextBox1_KeyPress);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Bell MT", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(396, -6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(352, 54);
            this.label1.TabIndex = 1;
            this.label1.Text = "User Expression";
            // 
            // richTextBox2
            // 
            this.richTextBox2.AutoSize = true;
            this.richTextBox2.Font = new System.Drawing.Font("Californian FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.Location = new System.Drawing.Point(113, 209);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(62, 24);
            this.richTextBox2.TabIndex = 6;
            this.richTextBox2.Text = "label3";
            // 
            // originalButtoncs6
            // 
            this.originalButtoncs6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.originalButtoncs6.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs6.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs6.Location = new System.Drawing.Point(858, 221);
            this.originalButtoncs6.Name = "originalButtoncs6";
            this.originalButtoncs6.Size = new System.Drawing.Size(162, 60);
            this.originalButtoncs6.Sizee = new System.Drawing.Size(96, 22);
            this.originalButtoncs6.TabIndex = 18;
            this.originalButtoncs6.txt = "Save Work";
            this.originalButtoncs6.ButtonClick += new Maa.ButtonClick(this.originalButtoncs6_ButtonClick);
            // 
            // History
            // 
            this.History.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.History.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.History.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.History.Font = new System.Drawing.Font("Californian FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.History.ForeColor = System.Drawing.Color.White;
            this.History.FormattingEnabled = true;
            this.History.ItemHeight = 16;
            this.History.Location = new System.Drawing.Point(799, 101);
            this.History.Name = "History";
            this.History.Size = new System.Drawing.Size(295, 112);
            this.History.TabIndex = 17;
            // 
            // originalButtoncs7
            // 
            this.originalButtoncs7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs7.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs7.Enabled = false;
            this.originalButtoncs7.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs7.FonttColor = System.Drawing.Color.White;
            this.originalButtoncs7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.originalButtoncs7.Location = new System.Drawing.Point(600, 145);
            this.originalButtoncs7.Name = "originalButtoncs7";
            this.originalButtoncs7.Size = new System.Drawing.Size(173, 56);
            this.originalButtoncs7.Sizee = new System.Drawing.Size(80, 22);
            this.originalButtoncs7.TabIndex = 19;
            this.originalButtoncs7.txt = "Integrate";
            this.originalButtoncs7.ButtonClick += new Maa.ButtonClick(this.originalButtoncs7_ButtonClick);
            // 
            // Expp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.originalButtoncs7);
            this.Controls.Add(this.originalButtoncs6);
            this.Controls.Add(this.History);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.originalButtoncs9);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.originalButtoncs3);
            this.Controls.Add(this.originalButtoncs10);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.originalButtoncs5);
            this.Controls.Add(this.originalButtoncs11);
            this.Controls.Add(this.originalButtoncs8);
            this.Controls.Add(this.originalButtoncs1);
            this.Controls.Add(this.originalButtoncs4);
            this.Controls.Add(this.originalButtoncs2);
            this.DoubleBuffered = true;
            this.Name = "Expp";
            this.Size = new System.Drawing.Size(1108, 510);
            this.Load += new System.EventHandler(this.Expp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    
        private OriginalButtoncs originalButtoncs1;
        private OriginalButtoncs originalButtoncs2;
        private OriginalButtoncs originalButtoncs3;
        private OriginalButtoncs originalButtoncs8;
        private OriginalButtoncs originalButtoncs9;
        private System.Windows.Forms.TextBox textBox1;
        private OriginalButtoncs originalButtoncs10;
        private OriginalButtoncs originalButtoncs11;
        private OriginalButtoncs originalButtoncs4;
        private System.Windows.Forms.Button button1;
        private OriginalButtoncs originalButtoncs5;
        private System.Windows.Forms.Label richTextBox2;
        public System.Windows.Forms.RichTextBox richTextBox1;
        private OriginalButtoncs originalButtoncs6;
        private System.Windows.Forms.ListBox History;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private OriginalButtoncs originalButtoncs7;
    }
}
