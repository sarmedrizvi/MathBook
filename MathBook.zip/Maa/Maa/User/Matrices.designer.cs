﻿namespace Maa
{
    partial class Matricess
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.originalButtoncs10 = new Maa.OriginalButtoncs();
            this.originalButtoncs13 = new Maa.OriginalButtoncs();
            this.originalButtoncs17 = new Maa.OriginalButtoncs();
            this.originalButtoncs6 = new Maa.OriginalButtoncs();
            this.originalButtoncs9 = new Maa.OriginalButtoncs();
            this.originalButtoncs12 = new Maa.OriginalButtoncs();
            this.originalButtoncs15 = new Maa.OriginalButtoncs();
            this.originalButtoncs7 = new Maa.OriginalButtoncs();
            this.originalButtoncs11 = new Maa.OriginalButtoncs();
            this.originalButtoncs5 = new Maa.OriginalButtoncs();
            this.originalButtoncs8 = new Maa.OriginalButtoncs();
            this.originalButtoncs4 = new Maa.OriginalButtoncs();
            this.originalButtoncs14 = new Maa.OriginalButtoncs();
            this.originalButtoncs2 = new Maa.OriginalButtoncs();
            this.originalButtoncs1 = new Maa.OriginalButtoncs();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Location = new System.Drawing.Point(3, 122);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(337, 382);
            this.panel1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox1.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(496, 18);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(133, 29);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "Row";
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox2.Font = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(496, 44);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(133, 29);
            this.textBox2.TabIndex = 2;
            this.textBox2.Text = "Column";
            this.textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bradley Hand ITC", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(59, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 46);
            this.label1.TabIndex = 4;
            this.label1.Text = "User Marix";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel2.Location = new System.Drawing.Point(782, 122);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(337, 382);
            this.panel2.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bradley Hand ITC", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(817, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(244, 46);
            this.label2.TabIndex = 4;
            this.label2.Text = "Output Marix";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(399, 195);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 24);
            this.label3.TabIndex = 7;
            this.label3.Text = "User Input";
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox3.Enabled = false;
            this.textBox3.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(363, 222);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(149, 30);
            this.textBox3.TabIndex = 8;
            this.textBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox3_KeyPress);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(642, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 24);
            this.label4.TabIndex = 7;
            this.label4.Text = "Output";
            // 
            // textBox4
            // 
            this.textBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox4.Enabled = false;
            this.textBox4.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(597, 222);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(141, 30);
            this.textBox4.TabIndex = 8;
            // 
            // textBox5
            // 
            this.textBox5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox5.Font = new System.Drawing.Font("Agency FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(363, 248);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(149, 30);
            this.textBox5.TabIndex = 9;
            this.textBox5.Text = "Column";
            this.textBox5.Visible = false;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Agency FB", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(393, 278);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 28);
            this.button1.TabIndex = 10;
            this.button1.Text = "Done";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(517, 253);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 33);
            this.button2.TabIndex = 11;
            this.button2.Text = "Answer";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // originalButtoncs10
            // 
            this.originalButtoncs10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs10.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs10.Enabled = false;
            this.originalButtoncs10.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs10.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs10.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs10.Location = new System.Drawing.Point(636, 510);
            this.originalButtoncs10.Name = "originalButtoncs10";
            this.originalButtoncs10.Size = new System.Drawing.Size(134, 50);
            this.originalButtoncs10.Sizee = new System.Drawing.Size(55, 50);
            this.originalButtoncs10.TabIndex = 6;
            this.originalButtoncs10.txt = "Inverse";
            this.originalButtoncs10.ButtonClick += new Maa.ButtonClick(this.originalButtoncs10_ButtonClick);
            // 
            // originalButtoncs13
            // 
            this.originalButtoncs13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs13.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs13.Enabled = false;
            this.originalButtoncs13.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs13.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs13.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs13.Location = new System.Drawing.Point(637, 453);
            this.originalButtoncs13.Name = "originalButtoncs13";
            this.originalButtoncs13.Size = new System.Drawing.Size(134, 50);
            this.originalButtoncs13.Sizee = new System.Drawing.Size(112, 50);
            this.originalButtoncs13.TabIndex = 6;
            this.originalButtoncs13.txt = "Type Of Matrix";
            this.originalButtoncs13.ButtonClick += new Maa.ButtonClick(this.originalButtoncs13_ButtonClick);
            // 
            // originalButtoncs17
            // 
            this.originalButtoncs17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs17.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs17.Enabled = false;
            this.originalButtoncs17.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs17.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs17.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs17.Location = new System.Drawing.Point(635, 397);
            this.originalButtoncs17.Name = "originalButtoncs17";
            this.originalButtoncs17.Size = new System.Drawing.Size(148, 50);
            this.originalButtoncs17.Sizee = new System.Drawing.Size(116, 50);
            this.originalButtoncs17.TabIndex = 6;
            this.originalButtoncs17.txt = "Number division";
            this.originalButtoncs17.ButtonClick += new Maa.ButtonClick(this.originalButtoncs17_ButtonClick);
            // 
            // originalButtoncs6
            // 
            this.originalButtoncs6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs6.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs6.Enabled = false;
            this.originalButtoncs6.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs6.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs6.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs6.Location = new System.Drawing.Point(641, 339);
            this.originalButtoncs6.Name = "originalButtoncs6";
            this.originalButtoncs6.Size = new System.Drawing.Size(132, 50);
            this.originalButtoncs6.Sizee = new System.Drawing.Size(94, 50);
            this.originalButtoncs6.TabIndex = 6;
            this.originalButtoncs6.txt = "Number Add";
            this.originalButtoncs6.ButtonClick += new Maa.ButtonClick(this.originalButtoncs6_ButtonClick);
            // 
            // originalButtoncs9
            // 
            this.originalButtoncs9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs9.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs9.Enabled = false;
            this.originalButtoncs9.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs9.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs9.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs9.Location = new System.Drawing.Point(496, 510);
            this.originalButtoncs9.Name = "originalButtoncs9";
            this.originalButtoncs9.Size = new System.Drawing.Size(133, 50);
            this.originalButtoncs9.Sizee = new System.Drawing.Size(57, 50);
            this.originalButtoncs9.TabIndex = 6;
            this.originalButtoncs9.txt = "Adjoint";
            this.originalButtoncs9.ButtonClick += new Maa.ButtonClick(this.originalButtoncs9_ButtonClick);
            // 
            // originalButtoncs12
            // 
            this.originalButtoncs12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs12.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs12.Enabled = false;
            this.originalButtoncs12.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs12.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs12.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs12.Location = new System.Drawing.Point(496, 454);
            this.originalButtoncs12.Name = "originalButtoncs12";
            this.originalButtoncs12.Size = new System.Drawing.Size(133, 50);
            this.originalButtoncs12.Sizee = new System.Drawing.Size(81, 50);
            this.originalButtoncs12.TabIndex = 6;
            this.originalButtoncs12.txt = "Solve for X";
            this.originalButtoncs12.ButtonClick += new Maa.ButtonClick(this.originalButtoncs12_ButtonClick);
            // 
            // originalButtoncs15
            // 
            this.originalButtoncs15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs15.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs15.Enabled = false;
            this.originalButtoncs15.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs15.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs15.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs15.Location = new System.Drawing.Point(485, 397);
            this.originalButtoncs15.Name = "originalButtoncs15";
            this.originalButtoncs15.Size = new System.Drawing.Size(150, 50);
            this.originalButtoncs15.Sizee = new System.Drawing.Size(123, 50);
            this.originalButtoncs15.TabIndex = 6;
            this.originalButtoncs15.txt = "Number Multiply";
            this.originalButtoncs15.ButtonClick += new Maa.ButtonClick(this.originalButtoncs15_ButtonClick);
            // 
            // originalButtoncs7
            // 
            this.originalButtoncs7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs7.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs7.Enabled = false;
            this.originalButtoncs7.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs7.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs7.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs7.Location = new System.Drawing.Point(359, 510);
            this.originalButtoncs7.Name = "originalButtoncs7";
            this.originalButtoncs7.Size = new System.Drawing.Size(132, 50);
            this.originalButtoncs7.Sizee = new System.Drawing.Size(91, 50);
            this.originalButtoncs7.TabIndex = 6;
            this.originalButtoncs7.txt = "Determinent";
            this.originalButtoncs7.ButtonClick += new Maa.ButtonClick(this.originalButtoncs7_ButtonClick);
            // 
            // originalButtoncs11
            // 
            this.originalButtoncs11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs11.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs11.Enabled = false;
            this.originalButtoncs11.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs11.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs11.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs11.Location = new System.Drawing.Point(360, 454);
            this.originalButtoncs11.Name = "originalButtoncs11";
            this.originalButtoncs11.Size = new System.Drawing.Size(131, 50);
            this.originalButtoncs11.Sizee = new System.Drawing.Size(46, 50);
            this.originalButtoncs11.TabIndex = 6;
            this.originalButtoncs11.txt = "Trace";
            this.originalButtoncs11.ButtonClick += new Maa.ButtonClick(this.originalButtoncs11_ButtonClick);
            // 
            // originalButtoncs5
            // 
            this.originalButtoncs5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs5.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs5.Enabled = false;
            this.originalButtoncs5.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs5.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs5.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs5.Location = new System.Drawing.Point(634, 283);
            this.originalButtoncs5.Name = "originalButtoncs5";
            this.originalButtoncs5.Size = new System.Drawing.Size(141, 50);
            this.originalButtoncs5.Sizee = new System.Drawing.Size(112, 50);
            this.originalButtoncs5.TabIndex = 6;
            this.originalButtoncs5.txt = "Multiply Matrix";
            this.originalButtoncs5.ButtonClick += new Maa.ButtonClick(this.originalButtoncs5_ButtonClick);
            // 
            // originalButtoncs8
            // 
            this.originalButtoncs8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs8.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs8.Enabled = false;
            this.originalButtoncs8.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs8.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs8.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs8.Location = new System.Drawing.Point(338, 397);
            this.originalButtoncs8.Name = "originalButtoncs8";
            this.originalButtoncs8.Size = new System.Drawing.Size(152, 50);
            this.originalButtoncs8.Sizee = new System.Drawing.Size(124, 50);
            this.originalButtoncs8.TabIndex = 6;
            this.originalButtoncs8.txt = "Number Subtract";
            this.originalButtoncs8.ButtonClick += new Maa.ButtonClick(this.originalButtoncs8_ButtonClick);
            // 
            // originalButtoncs4
            // 
            this.originalButtoncs4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs4.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs4.Enabled = false;
            this.originalButtoncs4.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs4.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs4.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs4.Location = new System.Drawing.Point(492, 339);
            this.originalButtoncs4.Name = "originalButtoncs4";
            this.originalButtoncs4.Size = new System.Drawing.Size(144, 50);
            this.originalButtoncs4.Sizee = new System.Drawing.Size(113, 50);
            this.originalButtoncs4.TabIndex = 6;
            this.originalButtoncs4.txt = "Subtract Matrix";
            this.originalButtoncs4.ButtonClick += new Maa.ButtonClick(this.originalButtoncs4_ButtonClick);
            // 
            // originalButtoncs14
            // 
            this.originalButtoncs14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs14.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs14.Enabled = false;
            this.originalButtoncs14.Fontt = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs14.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs14.ForeColor = System.Drawing.Color.Black;
            this.originalButtoncs14.Location = new System.Drawing.Point(359, 339);
            this.originalButtoncs14.Name = "originalButtoncs14";
            this.originalButtoncs14.Size = new System.Drawing.Size(128, 50);
            this.originalButtoncs14.Sizee = new System.Drawing.Size(83, 50);
            this.originalButtoncs14.TabIndex = 6;
            this.originalButtoncs14.txt = "Add Matrix";
            this.originalButtoncs14.ButtonClick += new Maa.ButtonClick(this.originalButtoncs14_ButtonClick);
            // 
            // originalButtoncs2
            // 
            this.originalButtoncs2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs2.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs2.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs2.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs2.Location = new System.Drawing.Point(472, 132);
            this.originalButtoncs2.Name = "originalButtoncs2";
            this.originalButtoncs2.Size = new System.Drawing.Size(167, 47);
            this.originalButtoncs2.Sizee = new System.Drawing.Size(115, 47);
            this.originalButtoncs2.TabIndex = 3;
            this.originalButtoncs2.txt = "Delete Matrix";
            this.originalButtoncs2.ButtonClick += new Maa.ButtonClick(this.originalButtoncs2_ButtonClick);
            // 
            // originalButtoncs1
            // 
            this.originalButtoncs1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.originalButtoncs1.BackColor = System.Drawing.Color.Transparent;
            this.originalButtoncs1.Fontt = new System.Drawing.Font("Californian FB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalButtoncs1.FonttColor = System.Drawing.Color.Black;
            this.originalButtoncs1.Location = new System.Drawing.Point(472, 75);
            this.originalButtoncs1.Name = "originalButtoncs1";
            this.originalButtoncs1.Size = new System.Drawing.Size(166, 54);
            this.originalButtoncs1.Sizee = new System.Drawing.Size(137, 54);
            this.originalButtoncs1.TabIndex = 1;
            this.originalButtoncs1.txt = "Generate Matrix";
            this.originalButtoncs1.ButtonClick += new Maa.ButtonClick(this.originalButtoncs1_ButtonClick);
            // 
            // Matricess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.originalButtoncs10);
            this.Controls.Add(this.originalButtoncs13);
            this.Controls.Add(this.originalButtoncs17);
            this.Controls.Add(this.originalButtoncs6);
            this.Controls.Add(this.originalButtoncs9);
            this.Controls.Add(this.originalButtoncs12);
            this.Controls.Add(this.originalButtoncs15);
            this.Controls.Add(this.originalButtoncs7);
            this.Controls.Add(this.originalButtoncs11);
            this.Controls.Add(this.originalButtoncs5);
            this.Controls.Add(this.originalButtoncs8);
            this.Controls.Add(this.originalButtoncs4);
            this.Controls.Add(this.originalButtoncs14);
            this.Controls.Add(this.originalButtoncs2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.originalButtoncs1);
            this.DoubleBuffered = true;
            this.Name = "Matricess";
            this.Size = new System.Drawing.Size(1122, 563);
            this.Load += new System.EventHandler(this.Matricess_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private OriginalButtoncs originalButtoncs1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private OriginalButtoncs originalButtoncs2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private OriginalButtoncs originalButtoncs4;
        private OriginalButtoncs originalButtoncs6;
        private OriginalButtoncs originalButtoncs8;
        private OriginalButtoncs originalButtoncs15;
        private OriginalButtoncs originalButtoncs17;
        private OriginalButtoncs originalButtoncs7;
        private OriginalButtoncs originalButtoncs9;
        private OriginalButtoncs originalButtoncs10;
        private OriginalButtoncs originalButtoncs11;
        private OriginalButtoncs originalButtoncs12;
        private OriginalButtoncs originalButtoncs13;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private OriginalButtoncs originalButtoncs5;
        private OriginalButtoncs originalButtoncs14;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}
