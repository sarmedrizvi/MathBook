﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maa
{
    public  class Matrices
    {
        int row;
        int column;
        double[,] elements;
        public int Row { get { return row; } set { row = value; } }
        public int Column { get { return column; } set { column = value; } }
        public double[,]  Elements { get { return elements; } set { elements = value; } }
        /// <summary>
        /// Default Constructor
        /// </summary>
        /// 
        public Matrices()
        {
            row = 0;
            column = 0;
            elements = new double[row, column];
        }
        /// <summary>
        /// Parameterized Constructor
        /// </summary>
        /// <param name="elements"></param>
        public Matrices(double [,] elements)
        {
            this.row = elements.GetLength(0);
            this.column = elements.GetLength(1);
            this.elements = new double[row, column];
            if (this.elements.Length==elements.Length)
            {
                for (int i = 0; i < row; i++)
                {
                    for (int j = 0; j < column; 
                        j++)
                    {
                        this.elements[i, j] = elements[i, j];
                    }
                }

            }
            else
            {
                throw new Exception ("Error");
            }
            
        }
        /// <summary>
        /// Static Determinent Method
        /// </summary>
        /// <param name="dimension"></param>
        /// <param name="matrix"></param>
        /// <returns></returns>
        public static double Determinent(int dimension,double[,] matrix)
        {
            if (matrix.GetLength(0)!=matrix.GetLength(1))
            {
                throw new Exception("No determinent");

            }
            else
            { 
           double[,] SUBMat = new double[dimension,dimension];
            double number = 0;
             if (dimension == 2)
                {
                    number = matrix[0, 0] * matrix[1, 1] - matrix[1, 0] * matrix[0, 1];
                }

                else
                {
                    for (int k = 0; k < dimension; k++)
                    {
                        int subi = 0;
                        for (int i = 1; i < dimension; i++)
                        {
                            int subj = 0;
                            for (int j = 0; j < dimension; j++)
                            {
                                if (j == k)
                                {
                                    continue;
                                }
                                SUBMat[subi, subj] = matrix[i, j];
                                subj++;
                            }
                            subi++;
                        }
                        number += (Math.Pow(-1, k) * matrix[0, k] * Determinent(dimension - 1, SUBMat));
                    }
                }
            
            return number;
                }
        }
        /// <summary>
        /// Static Adjoint Method
        /// </summary>
        /// <param name="Matrix"></param>
        /// <returns></returns>
        public static Matrices Adjoint(double [,] Matrix)
        {
            int s = 10;
            if (Matrix.GetLength(0) != Matrix.GetLength(1))
            {
                throw new Exception("No Adjoint");
            }
            else
            {
                Matrices r;
                int row = Matrix.GetLength(0);
                double[,] SUBMat1 = new double[row, row];
                double[,] SUBMat = new double[row, row];

                if (row == 2)
                {
                    SUBMat1[0, 0] = Matrix[1, 1];
                    SUBMat1[1, 1] = Matrix[0, 0];
                    SUBMat1[1, 0] = -Matrix[1, 0];
                    SUBMat1[0, 1] = -Matrix[0, 1];
                    r = new Matrices(SUBMat1);
                    return r;
                }

                else
                {
                    for (int l = 0; l < row; l++)
                    {
                        for (int k = 0; k < row; k++)
                        {
                            s++;
                            int subi = 0;
                            for (int i = 0; (i < row); i++)
                            {
                                if (i == l) { continue; }
                                int subj = 0;
                                for (int j = 0; j < row; j++)
                                {
                                    if (j == k)
                                    {
                                        continue;
                                    }
                                    SUBMat[subi, subj] = Matrix[i, j];
                                    subj++;
                                }
                                subi++;
                            }
                            SUBMat1[l, k] = (Math.Pow(-1, k+l) * Determinent(row - 1, SUBMat));
                       
                        }
                    }
                    r = new Matrices(SUBMat1);
                    Matrices m = r.Transpose();
                    return m;

                }
               
            }

        }
        /// <summary>
        /// Static Inverse Method
        /// </summary>
        /// <param name="matrices"></param>
        /// <returns></returns>
        public static Matrices Inverse(Matrices matrices)
        {
            if (Determinent(matrices.column, matrices.elements) == 0)
            {
                throw new Exception("It is not Invertible");
            }
            else
            {
                Matrices m = Adjoint(matrices.elements);
                Matrices m1 = m / Determinent(matrices.row, matrices.elements);
                return m1;
            }
                    
        
        }
        public override string ToString()
        {
            string matrix = "";
            for (int i = 0; i < elements.GetLength(0); i++)
            {
                for (int j = 0; j < elements.GetLength(1); j++)
                {
                    matrix+= elements[i, j] + " ";
                }
                matrix += "\n";
                
            }
            return matrix;
        }
        public Matrices Transpose()
        { double[,] a= new double[row, row];
            if (row==column)
            {
                for (int i = 0; i < row; i++)
                {
                    for (int j = 0; j < row; j++)
                    {
                        a[j, i] = elements[i, j];

                    }
                }
                Matrices matrices = new Matrices(a);
                return matrices;

            }
            else { throw new Exception("Cannot be transposed"); }
           
        }
        /// <summary>
        /// Addition Of Two Matrices
        /// </summary>
        /// <param name="m"></param>
        /// <param name="m1"></param>
        /// <returns></returns>
        public static Matrices operator+(Matrices m,Matrices m1)
        {
            double[,] matrix = new double[m.row, m.column];
            if (m.row==m1.row && m.column==m1.column)
            {
                for (int i = 0; i < m.row; i++)
                {
                    for (int j = 0; j < m.column; j++)
                    {
                        matrix[i, j] = m.elements[i, j] + m1.elements[i, j];
                    }
                }
                Matrices mat = new Matrices(matrix);
                return mat;
            }
            else
            { throw new Exception("Cannot be Added"); }
           
         
        }
        /// <summary>
        /// Addition of a matrix and a number.
        /// </summary>
        /// <param name="m"></param>
        /// <param name="a"></param>
        /// <returns></returns>
        public static Matrices operator +(Matrices m, double a)
        {
            double[,] matrix = new double[m.row, m.column];


            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = a + m.elements[i, j];
                }
            }
            Matrices mat = new Matrices(matrix);
            return mat;
        }
        public static Matrices operator +(double a,Matrices m)
        {
            double[,] matrix = new double[m.row, m.column];


            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = a + m.elements[i, j];
                }
            }
            Matrices mat = new Matrices(matrix);
            return mat;
        }
        /// <summary>
        /// Subtraction of two Matrices
        /// </summary>
        /// <param name="a"></param>
        /// <param name="m"></param>
        /// <returns></returns>
        public static Matrices operator -(double a, Matrices m)
        {
            double[,] matrix = new double[m.row, m.column];


            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = a - m.elements[i, j];
                }
            }
            Matrices mat = new Matrices(matrix);
            return mat;
        }
        /// <summary>
        /// Subtraction of a matrix and  number
        /// </summary>
        /// <param name="m"></param>
        /// <param name="a"></param>
        /// <returns></returns>
        public static Matrices operator -(Matrices m, double a)
        {
            double[,] matrix = new double[m.row, m.column];


            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = a - m.elements[i, j];
                }
            }
            Matrices mat = new Matrices(matrix);
            return mat;
        }


        public static Matrices operator -(Matrices m, Matrices m1)
        {
            double[,] matrix = new double[m.row, m.column];
            if (m.row == m1.row && m.column == m1.column)
            {
                for (int i = 0; i < m.row; i++)
                {
                    for (int j = 0; j < m.column; j++)
                    {
                        matrix[i, j] = m.elements[i, j] - m1.elements[i, j];
                     
                    }
                }
                Matrices mat = new Matrices(matrix);
                return mat;
            }
            else { throw new Exception("Cannot be subtract"); }
           
        }
        /// <summary>
        /// Multiplication of two matrices
        /// </summary>
        /// <param name="m"></param>
        /// <param name="m1"></param>
        /// <returns></returns>
        public static Matrices operator*(Matrices m,Matrices m1)
        {
            double[,] matrix = new double[m.row, m1.column];
          
            if (m.column==m1.row)
            {
                for (int i = 0; i < m.row; i++)
                {
                    for (int j = 0; j < m.row; j++)
                    {
                        for (int k = 0; k < m1.column; k++)
                        {
                            matrix[i, j] += m.elements[i, k] * m1.elements[k, j];
                        }
                    }

                }
                Matrices mat = new Matrices(matrix);
                return mat;
            }
            else
            {
                throw new Exception("Cannot be multiplied");
            }

        }
        /// <summary>
        /// Multiplication of a number and matrix
        /// </summary>
        /// <param name="m"></param>
        /// <param name="a"></param>
        /// <returns></returns>
        public static Matrices operator *(Matrices m, double a)
        {
            double[,] matrix = new double[m.row, m.column];
           
           
               
                    for (int j = 0; j < m.row; j++)
                    {
                        for (int k = 0; k < m.column; k++)
                        {
                        matrix[j, k] = m.elements[j, k] * a;
                        }
                    }

                
                Matrices mat = new Matrices(matrix);
                return mat;
          

        }
        public static Matrices operator *(double a,Matrices m)
        {
            double[,] matrix = new double[m.row, m.column];


            
                for (int j = 0; j < m.row; j++)
                {
                    for (int k = 0; k < m.column; k++)
                    {
                        matrix[j, k] = m.elements[j, k] * a;
                    }
                }

            
            Matrices mat = new Matrices(matrix);
            return mat;

           
        }
        /// <summary>
        /// Division of a number and matrix
        /// </summary>
        /// <param name="a"></param>
        /// <param name="m"></param>
        /// <returns></returns>
        public static Matrices operator /(double a, Matrices m)
        {
            double[,] matrix = new double[m.row, m.column];


           
                for (int j = 0; j < m.row; j++)
                {
                    for (int k = 0; k < m.column; k++)
                    {
                        matrix[j, k] = m.elements[j, k] / a;
                    }
                }

            
            Matrices mat = new Matrices(matrix);
            return mat;


        }
        public static Matrices operator /(Matrices m,double a)
        {
            double[,] matrix = new double[m.row, m.column];
          
                for (int j = 0; j < m.row; j++)
                {
                    for (int k = 0; k < m.column; k++)
                    {
                        matrix[j, k] = m.elements[j, k] / a;
                    }
                }

            
            Matrices mat = new Matrices(matrix);
            return mat;


        }
        /// <summary>
        /// Type of Matrix
        /// </summary>
        /// <param name="m"></param>
        /// <returns></returns>
        public static string TypeOfMatrix(Matrices m)
        {
            double number = 0;
            string type = "Cannot determine";
            if (m.elements.GetLength(0)==1 && m.elements.GetLength(1)!=1)
            {
                type = "Row Matrix and rectangular Matrix";
            }
            else if(m.elements.GetLength(1)== 1 && m.elements.GetLength(0) != 1)
            {
                type = "Column Matrix and rectangular Matrix";
            }
            else if(m.elements.GetLength(0)==m.elements.GetLength(1))
            {
                number = 0;
                type = "Square Matrix ";
                for (int i = 0; i < m.elements.GetLength(0); i++)
                {
                    for (int j = 0; j < m.elements.GetLength(1); j++)
                    {
                        number += m.elements[i, j];
                        if (number == 0) { type = "Null Matrix"; }

                    }
                }
            }
            
            return type;

        }
        /// <summary>
        /// Trace of a Matrix
        /// </summary>
        /// <param name="m"></param>
        /// <returns></returns>
        public static double Trace(Matrices m)
        {
            if (m.column==m.row)
            {
                double num = 0;
                for (int i = 0; i < m.elements.GetLength(0); i++)
                {
                    for (int j = 0; j < m.elements.GetLength(1); j++)
                    {
                        if (i == j)
                        {
                            num += m.elements[i, j];
                        }
                    }
                }
                return num;
            }
            else
            {
                throw new Exception("Should be a Square Matrix");
            }
           
        }
        /// <summary>
        /// Cramers Rule
        /// </summary>
        /// <param name="matrices"></param>
        /// <param name="equalsTo"></param>
        /// <returns></returns>
        public static string SolveMatrix(Matrices matrices,Matrices equalsTo)
        {
            string s = "";
            Matrices c;
            double n = Determinent(matrices.row, matrices.elements);
            double[] d = new double[matrices.row];
            if (equalsTo.column==1 && Determinent(matrices.column,matrices.elements)!=0 && matrices.row==equalsTo.row)
            {  
                for (int j = 0; j < matrices.column; j++)
                {
                    c = new Matrices(matrices.elements);
                   
                    for (int k = 0; k < matrices.row; k++)
                        {


                        c.elements[k,j] = equalsTo.elements[k, equalsTo.column-1];
                        

                        }
                    d[j]=(Determinent(c.column, c.elements) / n);
                    s += d[j] + " ";
                }
               

            }
            else
            {
                throw new Exception("No solution");
            
            }

            return s;
            
        }
        
      

    }
}
