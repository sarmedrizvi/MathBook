﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maa
{
    public struct Attribute
    {
        public string name;
        public string value;
    }
    class XMLwriter
    {public string WriteProlog()
        {
            string s = "<?xml version=\"1.0\" encoding=\"utf - 8\" ?>";
            return s;
        }
        public string WriteOpeningTag(string s, bool isAttribute)
        {
            string ss = !isAttribute ? "<" + s + ">" : "<" + s + " ";
            return ss;
           
        }
        public string WriteClosingTag(string s)
        {
            string ss = "</" + s + ">";
            return ss;
        }
        public string WriteAttributes(params Attribute[] s)
        {
            string code = "";
           
            for (int i = 0; i < s.Length; i++)
            {
                code += s[i].name +" = "+ "\""+ s[i].value + "\" ";
            }
            return code;
        }
    }
}
