﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Maa
{
    public partial class Graph : Form
    {
        string ss = "";
        public Graph()
        {
            InitializeComponent();
        }
        public Graph(string expp)
        {
          
            ss = expp;
            InitializeComponent();
        }

        Expp expp;
        public Graph(Expp expp)
        {
            ss = expp.richTextBox1.Text;
            InitializeComponent();
        }
       

        private void Graph_Load(object sender, EventArgs e)
        {
            chart1.Series[0].Points.Clear();chart1.Series[0].LegendText = ss;
            label1.Text = ss;
            Expression s = new Expression(ss);
            for (double i = 0.1; i < 10.0; i += 0.1)
            {
                chart1.Series[0].Points.AddXY(i, s.Evaluate(Convert.ToDouble(i)));
            }
            chart1.Visible = true;
        }

        private void originalButtoncs1_ButtonClick(object sender, EventArgs e)
        {

            chart1.Series[0].ChartType = SeriesChartType.Line;
        }

        private void originalButtoncs5_ButtonClick(object sender, EventArgs e)
        {
            using (SaveFileDialog o = new SaveFileDialog())
            {
                o.Filter = "Image Files|*.png;";
                o.Filter = "Bitmap Image (.bmp)|*.bmp|Gif Image (.gif)|*.gif|JPEG Image (.jpeg)|*.jpeg|Png Image (.png)|*.png|Tiff Image (.tiff)|*.tiff";
                o.Title = "Save Chart Image As file";
                o.DefaultExt = ".png";
                if (o.ShowDialog() == DialogResult.OK)
                {
                    var imgFormats = new Dictionary<string, ChartImageFormat>()
            {
                {".bmp", ChartImageFormat.Bmp},
                {".gif", ChartImageFormat.Gif},
                {".jpg", ChartImageFormat.Jpeg},
                {".jpeg", ChartImageFormat.Jpeg},
                {".png", ChartImageFormat.Png},
                {".tiff", ChartImageFormat.Tiff},
            };
                    var fileExt = System.IO.Path.GetExtension(o.FileName).ToString().ToLower();
                    if (imgFormats.ContainsKey(fileExt))
                    {
                        chart1.SaveImage(o.FileName, imgFormats[fileExt]);
                    }
                    else
                    {
                        MessageBox.Show(String.Format("Only image formats '{0}' supported", string.Join(", ", imgFormats.Keys)));
                    }
                }
            }
        }

        private void controlBar1_exit(object sender, EventArgs e)
        {
            this.Close();
        }

        private void originalButtoncs2_ButtonClick(object sender, EventArgs e)
        {

            chart1.Series[0].ChartType = SeriesChartType.Bar;
        }

        private void originalButtoncs3_ButtonClick(object sender, EventArgs e)
        {

            chart1.Series[0].ChartType = SeriesChartType.Column;
        }

        private void originalButtoncs4_ButtonClick(object sender, EventArgs e)
        {

            chart1.Series[0].ChartType = SeriesChartType.Spline;
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}
