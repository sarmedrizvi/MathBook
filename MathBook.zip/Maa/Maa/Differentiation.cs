﻿namespace Maa
{
    class Differentiation
    {
        Expression expression = new Expression();
        
        public static int add(params int[] par)
        {
            int a = 0;
            for (int i = 0; i < par.Length; i++)
            {
                a += par[i];
            }
            return a;
        }


        private  double Fun(double x)
        {
            return expression.Evaluate(x);
        }

        private double ForwardDifferentiation(double x, double h = 0.00001)
        {
            double x1, y1, x2, y2;
            x1 = x;
            y1 = Fun(x1);
            x2 = x + h;
            y2 = Fun(x2);

            return (y2 - y1) / h;

        }
        private static double Fun1(double x)
        {
            return x * x + 2;
        }

      

        private double BackwardDifferentiation(double x, double h = 0.00001)
        {
            double x1, y1, x2, y2;
            x1 = x - h;
            y1 = Fun(x1);
            x2 = x + h;
            y2 = Fun(x2);

            return (y2 - y1) / (2 * h);

        }
    }
}

