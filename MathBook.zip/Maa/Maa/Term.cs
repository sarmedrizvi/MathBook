﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
namespace Maa
{
    class Term
    { 
       public double coefficient;
       public int power;
       static int plusOrminus;
        List<double> coefficients = new List<double>();
        List<int> powers = new List<int>();
    
        public Term()
        {
            coefficient = 0;
            power = 0;
        }

        public Term(double coefficent,int power)
        {
            this.coefficient = coefficent;
            this.power = power;
        }
      
        private  Term(params Term[] t)
        {
            for (int i = 0; i < t.Length; i++)
            {
                coefficients.Add(t[i].coefficient);
                powers.Add(t[i].power);
            }
        }

       

        public Term(string TermExpression)
        {
            if (TermExpression.Length > 0)
            {
                if (TermExpression.IndexOf("x^") > -1)
                {
                    string CoefficientString = TermExpression.Substring(0, TermExpression.IndexOf("x^"));
                    int IndexofX = TermExpression.IndexOf("x^");
                    string PowerString = TermExpression.Substring(IndexofX + 2, (TermExpression.Length - 1) - (IndexofX + 1));
                    if (CoefficientString == "-")
                        this.coefficient = -1;
                    else if (CoefficientString == "+" | CoefficientString == "")
                        this.coefficient = 1;
                    else
                        this.coefficient = int.Parse(CoefficientString);

                    this.power = int.Parse(PowerString);
                }
                
                else if (TermExpression.IndexOf("x") > -1)
                {
                    this.power = 1;
                    string CoefficientString = TermExpression.Substring(0, TermExpression.IndexOf("x"));
                    if (CoefficientString == "-")
                        this.coefficient = -1;
                    else if (CoefficientString == "+" | CoefficientString == "")
                        this.coefficient = 1;
                    else
                        this.coefficient = int.Parse(CoefficientString);
                }
                else
                {
                    this.power = 0;
                    this.coefficient = int.Parse(TermExpression);
                }
            }
            else
            {
                this.power = 0;
                this.coefficient = 0;
            }
        }

        public static Term operator +(Term t1, Term t2)
        {
            plusOrminus = 1;
            double a;
         
            if (t1.power == t2.power)
            {
                a = t1.coefficient + t2.coefficient;
                Term t = new Term(a, t1.power);
                return t;
            }
            else
            {
                Term t11 = new Term(t1.coefficient, t1.power);
                Term t22 = new Term(t2.coefficient , t2.power);
                Term t33 = new Term(t11, t22);
                return t33;
            
            }

        }
        public static Term operator+(Term t1,double n)
        {
            if (t1.power==0)
            {
                double a = t1.coefficient + n;
                Term t = new Term(a, 0);
                return t;

            }
            else
            {
                
            
                Term t = new Term(n, 0);
                Term tt = new Term(t1,t);
                return tt;
            }
        }
        public static Term operator -(Term t1, double n)
        {
            if (t1.power == 0)
            {
                double a = t1.coefficient - n;
                Term t = new Term(a, 0);
                return t;

            }
            else
            {


                Term t = new Term(n, 0);
                Term tt = new Term(t1, -1*t);
                return tt;
            }
        }
        public static Term operator -(Term t1, Term t2)
        {
            double a;

            if (t1.power == t2.power)
            {
                a = t1.coefficient - t2.coefficient;
                Term t = new Term(a, t1.power);
                return t;
            }
            else
            {
              
                Term t33 = new Term(t1, t2);
                return t33;

            }
            
        }
        public static Term operator *(Term t1, Term t2)
        {
            double a;
            int b;
                a = t1.coefficient * t2.coefficient;
                b = t1.power + t2.power;
                Term t = new Term(a,b);
                return t;
       
        }
        public static Term operator*(Term t,double number)
        {
            double a;
            a = t.coefficient * number;
            Term termm = new Term(a, t.power);
            return termm;
           
        }
        public static Term operator *( double number,Term t)
        {
            double a;
            a = t.coefficient * number;
            Term termm = new Term(a, t.power);
            return termm;

        }
      
        public static Term operator ^(Term t,int power)
        {
            int p;
            double c;
           
           
            if (power==0)
            {
                p = 0;
                c = 1;

            }
            else
            {
                p = t.power * power;
                c = Math.Pow(t.coefficient, power);
            }
            Term term = new Term(c, p);
            return term;
        }
        public static Term operator /(Term t1, Term t2)
        {
            double a;
            int b;
            a = t1.coefficient / t2.coefficient;
            b = t1.power - t2.power;
            Term t = new Term(a, b);
            return t;
        }
        public static Term operator /(Term t1, double number)
        {
            double a;
            a = t1.coefficient / number;
            
            
            Term t = new Term(a, t1.power);
            return t;
        }
        public double Evaluate(double point)
        {
            return coefficient * (Math.Pow(point, power));
        }
        public double EqualsTo(double number)
        {
           
            double b;
            b = Math.Pow(number / this.coefficient, this.power);
            return b;
            
        }
        public static bool operator ==(Term t1, Term t2)
        {
            if (t1.coefficient == t2.coefficient && t1.power == t2.power )
            {
                return true;
            }
            else
                return false;

        }
        public static bool operator !=(Term t1, Term t2)
        {
            if (t1.coefficient != t2.coefficient || t1.power != t2.power)
            {
                return true;
            }
            else
                return false;

        }
        public static Term Differentiate(Term term)
        {
            int power;
            double coeff;
            coeff = term.coefficient * term.power;
            power = term.power - 1;
            Term t = new Term(coeff, power);
            return t;
        }
        public static Term Intergrate(Term term)
        {
            int power;
            double coeff;
            coeff = term.coefficient /( term.power + 1);
            power = term.power + 1;
            Term t = new Term(coeff, power);
            return t;

        }
        public override bool Equals(object obj)
        {
            if (obj is Term)
            {
                Term t2 = (Term)obj;
                if (this.coefficient == t2.coefficient && this.power == t2.power)
                    return true;
                else
                    return false;
            }
            return false;
        }
        public override int GetHashCode()
        {
            return 1;
        }
        public void Termm( ref int powers,ref double coeffi)
        {
            if (powers==0)
            {
         //       coefficient = 1;
            }
            if (coeffi==0)
            {
                power = 0;
            }

        }


        public override string ToString()
        {
            string s = "";

            if (coefficients.Count != 0 && powers.Count != 0)
            {

                for (int i = 0; i < coefficients.Count; i++)
                {
                    if (plusOrminus == 1)

                    { s += coefficients.Count - 1 == i ? coefficients[i] + "x^" + powers[i] + "" : coefficients[i] + "x^" + powers[i] + ""; }
                    else
                    {
                        s += coefficients.Count - 1 == i ? coefficients[i] + "x^" + powers[i] + "" : coefficients[i] + "x^" + powers[i] + "";
                    }
                }
                return s;
            }

            else
                Termm(ref power, ref coefficient);
                s = power==0?coefficient+"":power==1&&coefficient==1?"x":power==1?coefficient+"x" :coefficient==0? 0+"":coefficient==1?"x^"+power: coefficient + "x^" + power;
            return s;
        }

    }
}
