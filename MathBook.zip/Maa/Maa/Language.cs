﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maa
{
    class Language
    {
        bool isKeyWord;bool isClass;
       public static string[] keyword = { "add", "sub", "mul", "div", "power","diff","integ","solve","evaluate","graph","permutation","combination","factorial","req","expansion","mid","termwithoutX","sum" };
       public static string[] classes = { "expression", "bionomial" };
        public string Readsyntax(string s)
        {
            string[] c = s.Split(' ');
            for (int i = 0; i < classes.Length; i++)
            {
                if (classes[i] == c[0].ToLower())
                    isClass = true;

            }
            if (isClass)
            {
                string[] token = c[1].Split('.');

                for (int i = 0; i < keyword.Length; i++)
                {
                    if (keyword[i] == token[0])  isKeyWord = true;
                }
                if (isKeyWord)
                {
                    string[] vs = token[1].Split(',');
                    if (c[0]=="expression".ToLower())
                    { 
                        Expression e, e1, e2;
                        switch (token[0].ToLower())
                        {
                            case "add":
                                e = new Expression(vs[0]);
                                e1 = new Expression(vs[1]);
                                e2 = e + e1;
                                return e2.ToString();
                            case "sub":
                                e = new Expression(vs[0]);
                                e1 = new Expression(vs[1]);
                                e2 = e - e1;
                                return e2.ToString();
                            case "mul":
                                e = new Expression(vs[0]);
                                e1 = new Expression(vs[1]);
                                e2 = e * e1;
                                return e2.ToString();
                            case "div":
                                e = new Expression(vs[0]);
                                e1 = new Expression(vs[1]);
                                e2 = e * e1;
                                return e2.ToString();
                            case "power":
                                e = new Expression(vs[0]);
                                e2 = e ^ Convert.ToInt32(vs[1]);
                                return e2.ToString();
                            case "diff":
                                e = new Expression(vs[0]);
                                e2 = Expression.Differentiate(e);
                                return e2.ToString();
                            case "integ":
                                e = new Expression(vs[0]);
                                e2 = Expression.Integrate(e);
                                return e2.ToString();
                            case "solve":
                                e = new Expression(vs[0]);
                                return Expression.SolveforX(e).ToString();
                            case "evaluate":
                                e = new Expression(vs[0]);
                                return e.Evaluate(Convert.ToDouble(vs[1])).ToString();
                            case "graph":

                                Graph graph = new Graph(vs[0]);
                                graph.ShowDialog();
                                return "Graph Shown";
                            default:
                                throw new Exception("Incorrect Syntax");
                        }
                      
                    }
                    else if(c[0]=="bionomial".ToLower())
                    {
                        Expression e;
                        double b;
                        switch(token[0].ToLower())
                        {
                            case "permutation":
                                b = Binomial.nPr(Convert.ToInt32(vs[0]), Convert.ToInt32(vs[1]));
                                return b.ToString();
                            case "combination":

                                return Binomial.nCr(Convert.ToInt32(vs[0]), Convert.ToInt32(vs[1])).ToString();
                            case "factorial":

                                return Binomial.factorial(Convert.ToInt32(vs[0])).ToString();
                            case "req":

                                return Binomial.RequiredTerm(new Expression(vs[0]), Convert.ToInt32(vs[1]), Convert.ToInt32(vs[2])).ToString();
                            case "expansion":
                                e = new Expression(vs[0]);
                                return Binomial.BinonialExpansion(e, Convert.ToInt32(vs[1])).ToString();
                            case "mid":
                                e = new Expression(vs[0]);
                                return Binomial.MiddleTerm(e, Convert.ToInt32(vs[1])).ToString();
                            case "termwithoutX":
                                e = new Expression(vs[0]);
                                return Binomial.TermIndependedOfX(e, Convert.ToInt32(vs[1])).ToString();
                            case "sum":
                                e = new Expression(vs[0]);
                                return Binomial.SumOfCoefficient(e, Convert.ToInt32(vs[1])).ToString();
                            default:
                                throw new Exception("Incorrect Syntax");

                        }

                    }
                    else
                    { throw new Exception("Incorrect Syntax"); }


                }
                else
                { throw new Exception("Incorrect Syntax"); }
            }
            else
            { throw new Exception("Incorrect Syntax"); }
        }
     
    }
}
